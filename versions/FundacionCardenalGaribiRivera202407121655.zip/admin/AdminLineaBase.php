<?php

class AdminLineaBase extends Admin {

    public function __construct() {
        parent::__construct(new LineaBaseDAO());
    }

    public function recuperar_estados_mexico() {
        return $this->extraerInfoCampoEspecifico("domicilio_estado", "id_estado", "nombre");
    }

    public function recuperar_municipios_estado($id_estado) {
        return $this->extraerInfoCampoEspecifico("domicilio_municipio",
                        "id_municipio", "nombre", " WHERE id_estado = $id_estado ORDER BY nombre");
    }

    public function recuperar_vicarias() {
        return $this->extraerInfoCampoEspecifico("directorio_arquidiocesis_vicaria", "id_vicaria", "nombre");
    }

    public function recuperar_decanatos($id_vicaria) {
        return $this->extraerInfoCampoEspecifico("directorio_arquidiocesis_decanato",
                        "id_decanato", "nombre", " WHERE id_vicaria = $id_vicaria ORDER BY nombre");
    }

    public function recuperar_parroquias($id_decanato) {
        return $this->extraerInfoCampoEspecifico("directorio_arquidiocesis_comunidad_parroquial",
                        "id_comunidad", "nombre", " WHERE id_decanato = $id_decanato ORDER BY nombre");
    }

    public function recuperar_lista_escolaridad() {
        return $this->extraerInfoCampoEspecifico("ficha_inscripcion_campo_escolaridad", "id_escolaridad", "escolaridad");
    }

    public function recuperar_lista_estado_civil() {
        return $this->extraerInfoCampoEspecifico("ficha_inscripcion_campo_estado_civil", "id_estado_civil", "estado_civil");
    }

    public function recuperar_lista_ocupacion_actual() {
        return $this->extraerInfoCampoEspecifico("ficha_inscripcion_campo_ocupacion_actual", "id_ocupacion", "ocupacion");
    }

    public function recuperar_lista_ingreso_mensual_actual() {
        return $this->extraerInfoCampoEspecifico("ficha_inscripcion_campo_ingreso_mensual_actual", "id_ingreso", "ingreso");
    }

    public function listarEmprendoresConLineaBase() {
        /*$lista = [];
        foreach ($this->construirEmprendedor($this->dao->listarEmprendedoresLineaBase()) as $data) {
            $lista[] = $this->construirEmprendedor($data);
        }
        return $lista;*/
        return $this->dao->listarEmprendedoresLineaBase();
    }
}
