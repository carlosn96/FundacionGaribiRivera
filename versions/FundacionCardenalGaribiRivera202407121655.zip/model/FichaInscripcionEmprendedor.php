<?php

class FichaInscripcionEmprendedor {

    //private $nombre_completo;
    private $genero;
    private $fecha_nacimiento;
    //private $edad; //Atributo derivado
    private $correo_electronico;
    private $estado_civil;
    private $domicilio_calle;
    private $domicilio_numero;
    private $domicilio_colonia;
    private $domicilio_codigo_postal;
    private $domicilio_municipio;
    private $domicilio_estado;
    private $parroquia;
    private $escolaridad;
    private $discapacidad;
    private $ingreso_mensual;
    private $ocupacion;

    public function __construct($genero,
            $fecha_nacimiento, $correo_electronico,
            $estado_civil, $domicilio_calle, $domicilio_numero,
            $domicilio_colonia, $domicilio_codigo_postal, $domicilio_municipio,
            $domicilio_estado, $parroquia, $escolaridad, $discapacidad,
            $ingreso_mensual, $ocupacion) {
        $this->genero = $genero;
        $this->fecha_nacimiento = $fecha_nacimiento;
        $this->correo_electronico = $correo_electronico;
        $this->estado_civil = $estado_civil;
        $this->domicilio_calle = $domicilio_calle;
        $this->domicilio_numero = $domicilio_numero;
        $this->domicilio_colonia = $domicilio_colonia;
        $this->domicilio_codigo_postal = $domicilio_codigo_postal;
        $this->domicilio_municipio = $domicilio_municipio;
        $this->domicilio_estado = $domicilio_estado;
        $this->parroquia = $parroquia;
        $this->escolaridad = $escolaridad;
        $this->discapacidad = $discapacidad;
        $this->ingreso_mensual = $ingreso_mensual;
        $this->ocupacion = $ocupacion;
    }

    public function get_genero() {
        return $this->genero;
    }

    public function get_fecha_nacimiento() {
        return $this->fecha_nacimiento;
    }

    public function get_correo_electronico() {
        return $this->correo_electronico;
    }

    public function get_estado_civil() {
        return $this->estado_civil;
    }

    public function get_domicilio_calle() {
        return $this->domicilio_calle;
    }

    public function get_domicilio_numero() {
        return $this->domicilio_numero;
    }

    public function get_domicilio_colonia() {
        return $this->domicilio_colonia;
    }

    public function get_domicilio_codigo_postal() {
        return $this->domicilio_codigo_postal;
    }

    public function get_domicilio_municipio() {
        return $this->domicilio_municipio;
    }

    public function get_domicilio_estado() {
        return $this->domicilio_estado;
    }

    public function get_parroquia() {
        return $this->parroquia;
    }

    public function get_escolaridad() {
        return $this->escolaridad;
    }

    public function get_discapacidad() {
        return $this->discapacidad;
    }

    public function get_ingreso_mensual() {
        return $this->ingreso_mensual;
    }

    public function get_ocupacion() {
        return $this->ocupacion;
    }

    public function set_genero($genero): void {
        $this->genero = $genero;
    }

    public function set_fecha_nacimiento($fecha_nacimiento): void {
        $this->fecha_nacimiento = $fecha_nacimiento;
    }

    public function set_correo_electronico($correo_electronico): void {
        $this->correo_electronico = $correo_electronico;
    }

    public function set_estado_civil($estado_civil): void {
        $this->estado_civil = $estado_civil;
    }

    public function set_domicilio_calle($domicilio_calle): void {
        $this->domicilio_calle = $domicilio_calle;
    }

    public function set_domicilio_numero($domicilio_numero): void {
        $this->domicilio_numero = $domicilio_numero;
    }

    public function set_domicilio_colonia($domicilio_colonia): void {
        $this->domicilio_colonia = $domicilio_colonia;
    }

    public function set_domicilio_codigo_postal($domicilio_codigo_postal): void {
        $this->domicilio_codigo_postal = $domicilio_codigo_postal;
    }

    public function set_domicilio_municipio($domicilio_municipio): void {
        $this->domicilio_municipio = $domicilio_municipio;
    }

    public function set_domicilio_estado($domicilio_estado): void {
        $this->domicilio_estado = $domicilio_estado;
    }

    public function set_parroquia($parroquia): void {
        $this->parroquia = $parroquia;
    }

    public function set_escolaridad($escolaridad): void {
        $this->escolaridad = $escolaridad;
    }

    public function set_discapacidad($discapacidad): void {
        $this->discapacidad = $discapacidad;
    }

    public function set_ingreso_mensual($ingreso_mensual): void {
        $this->ingreso_mensual = $ingreso_mensual;
    }

    public function set_ocupacion($ocupacion): void {
        $this->ocupacion = $ocupacion;
    }

    public function to_array() {
        return get_object_vars($this);
    }

}
