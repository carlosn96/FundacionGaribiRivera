<div class="card">
    <div class="card-body">
        <h2 class="card-title">Evaluacion de la formación</h2>
        <p class="card-subtitle mb-3"> A continuación se muestra la información proporcionada sobre la evaluación </p>
        <div id="contenidoEvaluacion" class="row"></div>
    </div>
</div>
