const urlAPI = "api/SeguimientoCasoAPI.php";
function ready() {
    crearPeticion(urlAPI, {case: "recuperarEmprendedores"}, function (res) {
        var dataTabla = [];
        $.each(res, (i, emprendedor) => {
            dataTabla.push({
                "No.": emprendedor.idLineaBase,
                "Etapa": emprendedor.etapa,
                "Nombre": emprendedor.nombre,
                "Apellidos": emprendedor.apellidos,
                "Correo electrónico": emprendedor.correo
            });
        });
        var $tabla = construirTabla(dataTabla, "table-striped table-bordered display text-nowrap", "tablaEmprendedoresContenedor", "tablaEmprendedores");
        $("#tablaEmprendedores tbody").on("click", "tr", function () {
            $("#preloader").attr("hidden", false);
            
            const data = $tabla.row(this).data();
            const [idLineaBase, titulo, nombre, apellido, email] = data;
            $("#tituloModalEmprendedor").text(`${nombre} ${apellido}`);
            const contenido = `<h5 class="card-title">${titulo}</h5>
        <p class="card-text"><strong>Nombre:</strong> ${nombre} ${apellido}</p>
        <p class="card-text"><strong>Email:</strong> ${email}</p>
    `;
            $('#cardModalEmprendedorContent').html(contenido);
            crearPeticion(urlAPI, {case: "recuperarSeguimientoCaso", data: `idLineaBase=${idLineaBase}`}, (rs) => {
                const emprendedor = encodeURIComponent(JSON.stringify(data));
                const $btnSeguimiento = $("#btnDarSeguimiento");
                const seguimientoExistente = Array.isArray(rs.seguimientoCaso);
                const textBtn = seguimientoExistente ? "Hacer" : "Ver";
                const rsEncoded = seguimientoExistente ? '' : encodeURIComponent(JSON.stringify(rs));
                const urlBtn = seguimientoExistente
                        ? `../seguimientoCasoNuevo/?emprendedor=${emprendedor}`
                        : `../seguimientoCasoVista/?sc=12&emprendedor=${emprendedor}`;
                $btnSeguimiento.append(`${textBtn} seguimiento de caso`);
                $btnSeguimiento.attr("href", urlBtn);

                // Verificar si la URL se asigna correctamente
                console.log("URL generada: ", urlBtn);

                $("#modalEmprendedor").modal('show');
            });
        });


    });
}