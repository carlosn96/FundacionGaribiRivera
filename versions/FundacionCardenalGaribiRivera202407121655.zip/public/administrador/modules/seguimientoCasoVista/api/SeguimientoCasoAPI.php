<?php

include_once '../../../../../loader.php';

class SeguimientoCasoAPI extends API {

    function recuperarEmprendedores() {
        $this->enviarRespuesta(getAdminLineaBase()->listarEmprendoresConLineaBase());
    }
}

Util::iniciarAPI(SeguimientoCasoAPI::class);
