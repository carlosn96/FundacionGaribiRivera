<div class="card">
    <div class="card-body wizard-content">
        <h4 class="card-title">Segumiento de caso</h4>
        <p class="card-subtitle mb-3"> Listado de emprendedores con linea base completa</p>
        <p class="card-subtitle mb-3"> Haz clic en el registro deseado para ver las opciones </p>
        <div id="tablaEmprendedoresContenedor" class="table-responsive"></div>
    </div>
</div>


<div class="modal fade" id="modalEmprendedor">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tituloModalEmprendedor"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="card">
                    <div class="card-body" id="cardModalEmprendedorContent">
                    </div>
                    <div class="card-footer">
                        <div class="btn-group" role="group" aria-label="Botones de seguimiento">
                            <a type="button" class="btn btn-outline-success" id="btnDarSeguimiento"><i class="ti ti-icon"></i> Dar seguimiento</a>
                            <a type="button" class="btn btn-outline-danger" id="btnEliminarSeguimiento"><i class="ti ti-icon"></i> Eliminar seguimiento</a>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-warning" data-bs-dismiss="modal">Cancelar</button>
            </div>
        </div>
    </div>
</div>