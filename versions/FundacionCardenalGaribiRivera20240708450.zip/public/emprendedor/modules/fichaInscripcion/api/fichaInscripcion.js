

function ready() {
    $(document).ready(function () {

        function populateSelect(selectId, data, valueKey, textKey) {
            const select = $('#' + selectId);
            select.empty();
            select.append($('<option value="">Seleccionar</option>'));

            data.forEach(item => {
                const option = $('<option></option>')
                        .val(item[valueKey])
                        .text(item[textKey]);
                select.append(option);
            });
        }


        function loadData() {
            $.getJSON('api/escolaridad.json', function (data) {
                populateSelect('education', data, 'id_escolaridad', 'escolaridad');
            });

            $.getJSON('api/estado.json', function (data) {
                populateSelect('state', data, 'id_estado', 'nombre');
            });

            $.getJSON('api/estado_Civil.json', function (data) {
                populateSelect('maritalStatus', data, 'id_estado_civil', 'estado_civil');
            });

            $.getJSON('api/giro_Negocio.json', function (data) {
                populateSelect('businessType', data, 'id_giro', 'descripcion_giro');
            });
        }


        $('#state').change(function () {
            const selectedStateId = $(this).val();

            if (selectedStateId) {
                $.getJSON('api/municipio.json', function (data) {
                    const filteredMunicipios = data.filter(m => m.id_estado === selectedStateId);
                    populateSelect('municipality', filteredMunicipios, 'id_municipio', 'nombre');
                });
            } else {
                $('#municipality').empty();
                $('#municipality').append($('<option value="">Seleccionar</option>'));
            }
        });


        loadData();
    });

    $(document).ready(function () {
        // Función para mostrar u ocultar pasos basados en la selección del negocio
        function toggleStepsBasedOnBusiness() {
            const businessYes = $('#businessYes').is(':checked');
            const businessNo = $('#businessNo').is(':checked');

            if (businessYes) {
                $('#step2').show();
                $('#step3').show();
                $('#step4').hide();
            } else if (businessNo) {
                $('#step2').hide();
                $('#step3').hide();
                $('#step4').show();
            }
        }

        // Manejar el evento de cambio del radio button
        $('input[name="business"]').change(function () {
            toggleStepsBasedOnBusiness();
        });

        // Inicializar los pasos basados en el valor inicial del radio button
        toggleStepsBasedOnBusiness();

        // Manejar el evento de clic del botón "Submit"
        $('#wizard-form').on('submit', function (event) {
            event.preventDefault(); // Prevenir el envío del formulario por defecto

            const businessNo = $('#businessNo').is(':checked');

            if (businessNo) {
                // Si se selecciona "No", saltar al paso 4
                $('.step').hide(); // Ocultar todos los pasos
                $('#step4').show(); // Mostrar solo el paso 4
            } else {
                // Si se selecciona "Sí", proceder al siguiente paso
                const currentStep = $('.step:visible');
                const nextStep = currentStep.next('.step');

                if (nextStep.length) {
                    currentStep.hide();
                    nextStep.show();
                }
            }
        });
    });
    document.addEventListener('DOMContentLoaded', function () {
        const radioButtons = document.querySelectorAll('input[type="radio"]');
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        const strategyInput = document.createElement('input');
        strategyInput.type = 'text';
        strategyInput.classList.add('form-control', 'hidden');
        strategyInput.id = 'strategyValue';
        strategyInput.placeholder = 'Ingrese detalles de las estrategias';

        radioButtons.forEach(radio => {
            radio.addEventListener('change', function () {
                const inputId = this.id + 'Value';
                const input = document.getElementById(inputId);
                if (this.value === 'Yes') {
                    input.classList.remove('hidden');
                } else {
                    input.classList.add('hidden');
                }
            });
        });

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                if (checkbox.checked) {
                    document.getElementById('step3').appendChild(strategyInput);
                } else {
                    if (Array.from(checkboxes).every(box => !box.checked)) {
                        strategyInput.classList.add('hidden');
                    } else {
                        strategyInput.classList.remove('hidden');
                    }
                }
            });
        });
    });
    $(document).ready(function () {
        function toggleVisibility(inputId, radioButtonName) {
            $(`input[name=${radioButtonName}]`).on('change', function () {
                if ($(`#${radioButtonName}Yes`).is(':checked')) {
                    $(`#${inputId}`).removeClass('hidden');
                } else {
                    $(`#${inputId}`).addClass('hidden');
                }
            });
        }

        toggleVisibility('recordYesValue', 'recordEntries');
        toggleVisibility('salaryYesValue', 'assignedSalary');
        toggleVisibility('savingsYesValue', 'monthlySavings');
        toggleVisibility('productsYesValue', 'knowProducts');
        toggleVisibility('competitionDetails', 'identifyCompetition');

        function toggleDisabilityDetail(show) {
            if (show) {
                $('#disabilityDetailDiv').show();
            } else {
                $('#disabilityDetailDiv').hide();
            }
        }

        window.toggleDisabilityDetail = toggleDisabilityDetail;
    });

    function toggleDisabilityDetail(show) {
        const disabilityDetailDiv = document.getElementById('disabilityDetailDiv');
        disabilityDetailDiv.style.display = show ? 'block' : 'none';
    }

    function toggleParishCount(show) {
        const parishCountDiv = document.getElementById('parishCountDiv');
        parishCountDiv.style.display = show ? 'block' : 'none';
    }

    // Asegúrate de que los campos estén ocultos inicialmente
    document.addEventListener('DOMContentLoaded', function () {
        document.getElementById('disabilityDetailDiv').style.display = 'none';
        document.getElementById('parishCountDiv').style.display = 'none';
    });
}


function enviarForm() {
    crearPeticion("api/EvaluacionFormacionAPI.php", {case: "guardarEvaluacion", data: $(this).serialize()});
}

