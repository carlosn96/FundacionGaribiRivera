function ready() {
    $('input[name="huboBeneficioPersonal"]').change(function () {
        $('#beneficiosObtenidos').prop('disabled', !($(this).val() === '1'));
    });

    $('input[name="cuentaConSistemaAhorro"]').change(function () {
        var isEnabled = $(this).val() === '1';
        $('#detallesSistemaAhorro, #objetivoAhorro, #ahorroMensual').prop('disabled', !isEnabled);
    });
}

function enviarForm() {
    crearPeticion("api/EvaluacionFormacionAPI.php", {
        case: "guardarEvaluacion",
        data: $("#evaluacionForm").serialize()
    }, print, printError);
}

