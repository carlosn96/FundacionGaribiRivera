<?php

header("Location: inicio/");
