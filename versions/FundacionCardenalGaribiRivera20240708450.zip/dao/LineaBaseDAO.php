<?php

class LineaBaseDAO extends DAO {
    public function recuperarEstados() {
        //return $this->
    }
    
    public function guardarEvaluacionFormacion(EvaluacionFormacion $evaluacion) {
        var_dump($evaluacion);
    }
}
