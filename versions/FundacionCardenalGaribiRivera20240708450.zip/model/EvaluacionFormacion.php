<?php

class EvaluacionFormacion {

    use Entidad;

    private $beneficioPersonal;
    private $beneficiosObtenidos;
    private $ventasMensuales;
    private $gastosMensuales;
    private $utilidadesMensuales;
    private $sueldoMensual;
    private $ingresoPrincipalPersonal;
    private $ingresoPrincipalFamiliar;
    private $habitoAhorro;
    private $sistemaAhorro;
    private $detallesSistemaAhorro;
    private $objetivoAhorro;
    private $ahorroMensual;

    public function __construct($beneficioPersonal, $beneficiosObtenidos,
            $ventasMensuales, $gastosMensuales, $utilidadesMensuales, $sueldoMensual,
            $ingresoPrincipalPersonal, $ingresoPrincipalFamiliar, $habitoAhorro,
            $sistemaAhorro, $detallesSistemaAhorro, $objetivoAhorro, $ahorroMensual) {
        $this->beneficioPersonal = $beneficioPersonal;
        $this->beneficiosObtenidos = $beneficiosObtenidos;
        $this->ventasMensuales = $ventasMensuales;
        $this->gastosMensuales = $gastosMensuales;
        $this->utilidadesMensuales = $utilidadesMensuales;
        $this->sueldoMensual = $sueldoMensual;
        $this->ingresoPrincipalPersonal = $ingresoPrincipalPersonal;
        $this->ingresoPrincipalFamiliar = $ingresoPrincipalFamiliar;
        $this->habitoAhorro = $habitoAhorro;
        $this->sistemaAhorro = $sistemaAhorro;
        $this->detallesSistemaAhorro = $detallesSistemaAhorro;
        $this->objetivoAhorro = $objetivoAhorro;
        $this->ahorroMensual = $ahorroMensual;
    }

    public function getBeneficioPersonal() {
        return $this->beneficioPersonal;
    }

    public function getBeneficiosObtenidos() {
        return $this->beneficiosObtenidos;
    }

    public function getVentasMensuales() {
        return $this->ventasMensuales;
    }

    public function getGastosMensuales() {
        return $this->gastosMensuales;
    }

    public function getUtilidadesMensuales() {
        return $this->utilidadesMensuales;
    }

    public function getSueldoMensual() {
        return $this->sueldoMensual;
    }

    public function getIngresoPrincipalPersonal() {
        return $this->ingresoPrincipalPersonal;
    }

    public function getIngresoPrincipalFamiliar() {
        return $this->ingresoPrincipalFamiliar;
    }

    public function getHabitoAhorro() {
        return $this->habitoAhorro;
    }

    public function getSistemaAhorro() {
        return $this->sistemaAhorro;
    }

    public function getDetallesSistemaAhorro() {
        return $this->detallesSistemaAhorro;
    }

    public function getObjetivoAhorro() {
        return $this->objetivoAhorro;
    }

    public function getAhorroMensual() {
        return $this->ahorroMensual;
    }

    public function setBeneficioPersonal($beneficioPersonal): void {
        $this->beneficioPersonal = $beneficioPersonal;
    }

    public function setBeneficiosObtenidos($beneficiosObtenidos): void {
        $this->beneficiosObtenidos = $beneficiosObtenidos;
    }

    public function setVentasMensuales($ventasMensuales): void {
        $this->ventasMensuales = $ventasMensuales;
    }

    public function setGastosMensuales($gastosMensuales): void {
        $this->gastosMensuales = $gastosMensuales;
    }

    public function setUtilidadesMensuales($utilidadesMensuales): void {
        $this->utilidadesMensuales = $utilidadesMensuales;
    }

    public function setSueldoMensual($sueldoMensual): void {
        $this->sueldoMensual = $sueldoMensual;
    }

    public function setIngresoPrincipalPersonal($ingresoPrincipalPersonal): void {
        $this->ingresoPrincipalPersonal = $ingresoPrincipalPersonal;
    }

    public function setIngresoPrincipalFamiliar($ingresoPrincipalFamiliar): void {
        $this->ingresoPrincipalFamiliar = $ingresoPrincipalFamiliar;
    }

    public function setHabitoAhorro($habitoAhorro): void {
        $this->habitoAhorro = $habitoAhorro;
    }

    public function setSistemaAhorro($sistemaAhorro): void {
        $this->sistemaAhorro = $sistemaAhorro;
    }

    public function setDetallesSistemaAhorro($detallesSistemaAhorro): void {
        $this->detallesSistemaAhorro = $detallesSistemaAhorro;
    }

    public function setObjetivoAhorro($objetivoAhorro): void {
        $this->objetivoAhorro = $objetivoAhorro;
    }

    public function setAhorroMensual($ahorroMensual): void {
        $this->ahorroMensual = $ahorroMensual;
    }
}
