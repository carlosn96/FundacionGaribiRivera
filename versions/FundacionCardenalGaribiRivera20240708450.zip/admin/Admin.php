<?php

abstract class Admin {
    private static $instances = [];
    
    public static function instance() {
        $calledClass = static::class;
        if (!isset(self::$instances[$calledClass])) {
            self::$instances[$calledClass] = new $calledClass();
        }
        return self::$instances[$calledClass];
    }
}