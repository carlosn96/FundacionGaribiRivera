<?php

class AdminUsuario {

    private $dao;

    public function __construct() {
        $this->dao = new UsuarioDAO();
    }

    public function existeCorreo($correo) {
        return $this->dao->existeCorreo($correo);
    }

    public function buscarUsuarioPorCorreo($correo) {
        return $this->dao->buscarUsuarioPorCorreo($correo);
    }

    public function insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario) {
        return $this->dao->insertarUsuario($nombre, $apellidos, $correo, $numero_celular, Util::encriptarContrasenia($contrasena), $id_tipo_usuario);
    }

    public function cambiarContrasena($correo, $contrasena) {
        return $this->dao->cambiarContrasena($correo, Util::encriptarContrasenia($contrasena));
    }

}
