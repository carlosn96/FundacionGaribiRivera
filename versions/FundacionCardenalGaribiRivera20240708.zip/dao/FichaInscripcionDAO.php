<?php

class FichaInscripcionDAO extends DAO {
    public function recuperarEstados() {
        //return $this->
    }
}
