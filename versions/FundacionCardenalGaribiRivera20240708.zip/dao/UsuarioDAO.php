<?php

class UsuarioDAO extends DAO {

    private const NOMBRE_TABLA = "usuario";
    private const BUSCAR_USUARIO_CORREO = "SELECT * FROM " . self::NOMBRE_TABLA . " WHERE correo_electronico = ?";
    private const ACTUALIZAR_CONTRASENA = "UPDATE " . self::NOMBRE_TABLA . " SET contrasena = ? WHERE correo_electronico = ?";
    private const INSERTAR_USUARIO = "INSERT INTO " . self::NOMBRE_TABLA . " "
            . "(nombre, apellidos, correo_electronico, numero_celular, contrasena, id_tipo_usuario) VALUES (?, ?, ?, ?, ?, ?)";

    private function consultarUsuarioCorreo($correo) {
        $prep = $this->prepararInstruccion(self::BUSCAR_USUARIO_CORREO);
        $prep->agregarString($correo);
        return $prep->ejecutarConsulta();
    }

    public function existeCorreo($correo) {
        $consulta = $this->consultarUsuarioCorreo($correo);
        return count($consulta) > 0;
    }

    public function buscarUsuarioPorCorreo($correo) {
        $result = $this->consultarUsuarioCorreo($correo);
        return count($result) > 0 ? $result : false;
    }

    public function cambiarContrasena($correo, $contrasena) {
        $stmt = $this->prepararInstruccion(self::ACTUALIZAR_CONTRASENA);
        $stmt->agregarString($contrasena);
        $stmt->agregarString($correo);
        return $stmt->ejecutar();
    }

    public function insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario) {
        $stmt = $this->prepararInstruccion(self::INSERTAR_USUARIO);
        $stmt->agregarString($nombre);
        $stmt->agregarString($apellidos);
        $stmt->agregarString($correo);
        $stmt->agregarString($numero_celular);
        $stmt->agregarString($contrasena);
        $stmt->agregarInt($id_tipo_usuario);
        return $stmt->ejecutar();
    }

}
