
<div class="preloader">
    <img src="../../../assets/images/logos/loader.svg" alt="loader" class="lds-ripple img-fluid" />
</div>
<div id="overlay" class="overlay">
    <div class="spinner-container">
        <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
</div>