<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme">
    <head>
        <?php
        include '../../includes/head.php';
        ?>
    </head>
    <body>
        <!-- Preloader -->
        <?php
        include '../../includes/preloader.php';
        ?>
        <div id="main-wrapper">
            <!-- Sidebar Start -->
            <?php
            include '../../includes/aside-vertical.php';
            ?>
            <!--  Sidebar End -->
            <div class="page-wrapper">
                <?php
                include '../../includes/aside-horizontal.php';
                ?>
                <div class="body-wrapper">
                    <div class="container-fluid">
                        <!--  Header Start -->
                        <header class="topbar sticky-top">
                            <div class="with-vertical">
                                <!-- ---------------------------------- -->
                                <!-- Start Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <?php
                                include '../../includes/header.php';
                                ?>
                                <!-- ---------------------------------- -->
                                <!-- End Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <!--  Mobilenavbar -->
                                <?php
                                include '../../includes/mobilenavbar.php';
                                ?>
                            </div>
                        </header>
                        <!--  Header End -->
                        <div class="row">
                            <div class="d-flex align-items-stretch">
                                <div class="card">
                                    <div class="card-body wizard-content">
                                        <h4 class="card-title">Para continuar llena tu ficha de inscripción</h4>
                                        <p class="card-subtitle mb-3"> Es muy importante tener tus datos actualizados </p>
                                        <form action="#" class="validation-wizard wizard-circle">
                                            <!-- Step 1 -->
                                            <h6>Datos Personales</h6>
                                            <section>
                                                <div class="row">
                                                    <!-- Nombre y Apellidos -->
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="firstName">Nombre(s): <span class="danger">*</span></label>
                                                            <input type="text" class="form-control " id="firstName" name="firstName" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="lastName">Apellidos: <span class="danger">*</span></label>
                                                            <input type="text" class="form-control " id="lastName" name="lastName" />
                                                        </div>
                                                    </div>

                                                    <!-- Teléfonos -->
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="phoneFixed">Teléfono fijo:</label>
                                                            <input type="tel" class="form-control" id="phoneFixed" name="phoneFixed" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="mobilePhone">Teléfono móvil:</label>
                                                            <input type="tel" class="form-control" id="mobilePhone" name="mobilePhone" />
                                                        </div>
                                                    </div>

                                                    <!-- Dirección -->
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="street">Calle:</label>
                                                            <input type="text" class="form-control" id="street" name="street" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="betweenStreets">Entre:</label>
                                                            <input type="text" class="form-control" id="betweenStreets" name="betweenStreets" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="andStreet">Y calle:</label>
                                                            <input type="text" class="form-control" id="andStreet" name="andStreet" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="externalNumber">Número exterior:</label>
                                                            <input type="text" class="form-control" id="externalNumber" name="externalNumber" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <div class="mb-1">
                                                            <label class="form-label" for="internalNumber">Interior:</label>
                                                            <input type="text" class="form-control" id="internalNumber" name="internalNumber" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="neighborhood">Colonia:</label>
                                                            <input type="text" class="form-control" id="neighborhood" name="neighborhood" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="postalCode">Código postal:</label>
                                                            <input type="text" class="form-control" id="postalCode" name="postalCode" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="yearsLiving">Tiempo habitando aquí (Años):</label>
                                                            <input type="number" class="form-control" id="yearsLiving" name="yearsLiving" />
                                                        </div>
                                                    </div>

                                                    <!-- Estado Civil y Escolaridad -->
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="maritalStatus">Estado Civil:</label>
                                                            <select class="form-select " id="maritalStatus" name="maritalStatus">
                                                                <option value="">Seleccionar</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="education">Escolaridad:</label>
                                                            <select class="form-select " id="education" name="education">
                                                                <option value="">Seleccionar</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="state">Estado:</label>
                                                            <select class="form-select " id="state" name="state">
                                                                <option value="">Seleccionar</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="municipality">Municipio:</label>
                                                            <select class="form-select " id="municipality" name="municipality">
                                                                <option value="">Seleccionar</option>
                                                            </select>
                                                        </div>
                                                    </div>


                                                    <!-- Edad y Género -->
                                                    <div class="col-md-5">
                                                        <span><br></span>
                                                        <div class="mb-3">
                                                            <label class="form-label" for="age">Edad:</label>
                                                            <div class="form-check form-check-inline">
                                                                <input type="radio" class="custom-control-input" id="age1" name="age" value="18-28">
                                                                <label class="custom-control-label" for="age1">18-28 Años</label>
                                                            </div>
                                                            <div class="form-check form-check-inline">
                                                                <input type="radio" class="custom-control-input" id="age2" name="age" value="29-40">
                                                                <label class="custom-control-label" for="age2">29-40 Años</label>
                                                            </div>
                                                            <div class="form-check form-check-inline">
                                                                <input type="radio" class="custom-control-input" id="age3" name="age" value="41-60">
                                                                <label class="custom-control-label" for="age3">41-60 Años</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Género:</label>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="genderFemale" name="gender"
                                                                   value="female">
                                                            <label class="custom-control-label" for="genderFemale">Mujer</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="genderMale" name="gender" value="male">
                                                            <label class="custom-control-label" for="genderMale">Hombre</label>
                                                        </div>
                                                    </div>
                                                    <!-- Discapacidad -->
                                                    <div class="col-md-6">
                                                        <label class="form-label">¿Cuentas con alguna discapacidad?</label>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="disabilityYes" name="disability"
                                                                   value="yes" onclick="toggleDisabilityDetail(true)">
                                                            <label class="custom-control-label" for="disabilityYes">Sí</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="disabilityNo" name="disability"
                                                                   value="no" onclick="toggleDisabilityDetail(false)">
                                                            <label class="custom-control-label" for="disabilityNo">No</label>
                                                        </div>
                                                        <div class="mb-3" id="disabilityDetailDiv" style="display: none;">
                                                            <input type="text" class="form-control" id="disabilityDetail" name="disabilityDetail"
                                                                   placeholder="¿Sí? ¿Cuál?" />
                                                        </div>
                                                    </div>

                                                    <!-- Comunidad Parroquial -->
                                                    <div class="col-md-6">
                                                        <label class="form-label">¿Existe alguna comunidad parroquial cerca de ti? (Capilla, parroquia
                                                            o templo)</label>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="parishYes" name="parish" value="yes"
                                                                   onclick="toggleParishCount(true)">
                                                            <label class="custom-control-label" for="parishYes">Sí</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input type="radio" class="custom-control-input" id="parishNo" name="parish" value="no"
                                                                   onclick="toggleParishCount(false)">
                                                            <label class="custom-control-label" for="parishNo">No</label>
                                                        </div>
                                                        <div class="mb-3 hidden" id="parishCountDiv">
                                                            <input type="text" class="form-control" id="parishCount" name="parishCount"
                                                                   placeholder="¿Cuántas?" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                            <!-- Step 3 -->
                                            <h6>Datos del negocio</h6>
                                            <section id="step3">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="street">Calle:</label>
                                                            <input type="text" class="form-control" id="street" name="street" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="betweenStreets">Entre:</label>
                                                            <input type="text" class="form-control" id="betweenStreets" name="betweenStreets" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="andStreet">Y calle:</label>
                                                            <input type="text" class="form-control" id="andStreet" name="andStreet" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="externalNumber">Número exterior:</label>
                                                            <input type="text" class="form-control" id="externalNumber" name="externalNumber" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <div class="mb-1">
                                                            <label class="form-label" for="internalNumber">Interior:</label>
                                                            <input type="text" class="form-control" id="internalNumber" name="internalNumber" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-2">
                                                            <label class="form-label" for="neighborhood">Colonia:</label>
                                                            <input type="text" class="form-control" id="neighborhood" name="neighborhood" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="postalCode">Código postal:</label>
                                                            <input type="text" class="form-control" id="postalCode" name="postalCode" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="yearsLiving">¿Tiempo (años) del negocio?</label>
                                                            <input type="number" class="form-control" id="yearsLiving" name="yearsLiving" />
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <span>
                                                            <br>
                                                        </span>
                                                    </div>
                                                    <div>
                                                        <span>
                                                            <br>
                                                        </span>
                                                    </div>
                                                    <div class="row">
                                                        <hr style="border-color:red;  ">
                                                        <div>
                                                            <span>
                                                                <br>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="mb-3">
                                                                <label class="form-label" for="street">¿Cuántos empleados trabajan en tu
                                                                    negocio?</label>
                                                                <input type="number" class="form-control" id="street" name="street" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="mb-3">
                                                                <label class="form-label" for="betweenStreets">¿Cuáles son las ventas totales
                                                                    mensuales en tu negocio?</label>
                                                                <input type="text" class="form-control" id="betweenStreets" name="betweenStreets" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="mb-3">
                                                                <label class="form-label" for="andStreet">¿Cuáles son los costos totales mensuales
                                                                    de tu negocio?</label>
                                                                <input type="text" class="form-control" id="andStreet" name="andStreet" />
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="mb-4">
                                                                <label class="form-label" for="externalNumber">¿Cuál es la utilidad mensual de tu
                                                                    negocio?</label>
                                                                <input type="text" class="form-control" id="externalNumber" name="externalNumber" />
                                                            </div>
                                                        </div>
                                                        <div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <div class="mb-4">
                                                                <label class="form-label" for="internalNumber">¿Cuál es el porcentaje de
                                                                    ganancia?</label>
                                                                <input type="text" class="form-control" id="internalNumber" name="internalNumber" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="mb-3">
                                                            <label class="form-label">¿Qué estrategias utilizas para incrementar tus ventas?</label>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="socialMedia"
                                                                       value="Redes sociales">
                                                                <label class="form-check-label" for="socialMedia">Redes sociales</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="customerService"
                                                                       value="Mejorar atención al cliente">
                                                                <label class="form-check-label" for="customerService">Mejorar atención al
                                                                    cliente</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="businessImage"
                                                                       value="Cuidar la imagen del negocio">
                                                                <label class="form-check-label" for="businessImage">Cuidar la imagen del
                                                                    negocio</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="additionalServices"
                                                                       value="Servicios adicionales">
                                                                <label class="form-check-label" for="additionalServices">Servicios adicionales</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="none" value="Ninguno">
                                                                <label class="form-check-label" for="none">Ninguno</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="maritalStatus">Giro del negocio</label>
                                                            <select class="form-select " id="maritalStatus" name="maritalStatus">
                                                                <option value="">Seleccionar</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>

                                            <!-- Step 4 -->
                                            <h6>Información complementaria</h6>
                                            <section id="step4">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="street">¿Ocupación Actual?</label>
                                                            <input type="text" class="form-control" id="street" name="street" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="betweenStreets">¿Cúal es tu ingreso total
                                                                general?</label>
                                                            <input type="text" class="form-control" id="betweenStreets" name="betweenStreets" />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="mb-3">
                                                            <label class="form-label" for="andStreet">¿Tienes dependientes economicos?</label>
                                                            <input type="text" class="form-control" id="andStreet" name="andStreet" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include '../../includes/scriptsjs.php';
        ?>
        <script src="api/fichaInscripcion.js"></script>
    </body>
</html>