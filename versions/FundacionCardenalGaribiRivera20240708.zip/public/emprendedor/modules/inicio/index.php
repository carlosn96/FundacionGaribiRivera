<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme">
    <head>
        <?php
        include '../../includes/head.php';
        ?>
    </head>
    <body>
        <!-- Preloader -->
        <?php
        include '../../includes/preloader.php';
        ?>
        <div id="main-wrapper">
            <!-- Sidebar Start -->
            <?php
            include '../../includes/aside-vertical.php';
            ?>
            <!--  Sidebar End -->
            <div class="page-wrapper">
                <?php
                include '../../includes/aside-horizontal.php';
                ?>
                <div class="body-wrapper">
                    <div class="container-fluid">
                        <!--  Header Start -->
                        <header class="topbar sticky-top">
                            <div class="with-vertical">
                                <!-- ---------------------------------- -->
                                <!-- Start Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <?php
                                include '../../includes/header.php';
                                ?>
                                <!-- ---------------------------------- -->
                                <!-- End Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <!--  Mobilenavbar -->
                                <?php
                                include '../../includes/mobilenavbar.php';
                                ?>
                            </div>
                        </header>
                        <!--  Header End -->
                        <div class="row">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include '../../includes/scriptsjs.php';
        ?>
        <script src="api/inicio.js"></script>
    </body>
</html>