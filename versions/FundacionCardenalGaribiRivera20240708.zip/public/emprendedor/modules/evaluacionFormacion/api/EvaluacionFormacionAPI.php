<?php

include_once '../../../../../loader.php';

class EvaluacionFormacionAPI extends API {

    function guardarEvaluacion() {
        $this->enviarResultadoOperacion(true);
    }

}

Util::iniciarAPI(EvaluacionFormacionAPI::class);
