function ready() {
    $('input[name="beneficioPersonal"]').change(function () {
        if ($(this).val() === '1') {
            $('#beneficiosObtenidos').prop('disabled', false);
        } else {
            $('#beneficiosObtenidos').prop('disabled', true);
        }
    });

    $('input[name="sistemaAhorro"]').change(function () {
        if ($(this).val() === '1') {
            $('#detallesSistemaAhorro').prop('disabled', false);
            $('#objetivoAhorro').prop('disabled', false);
            $('#ahorroMensual').prop('disabled', false);
        } else {
            $('#detallesSistemaAhorro').prop('disabled', true);
            $('#objetivoAhorro').prop('disabled', true);
            $('#ahorroMensual').prop('disabled', true);
        }
    });
}

function enviarForm() {
    crearPeticion("api/EvaluacionFormacionAPI.php", {case: "guardarEvaluacion", data: $(this).serialize()});
}

