<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme">
    <head>
        <?php
        include '../../includes/head.php';
        ?>
    </head>
    <body>
        <!-- Preloader -->
        <?php
        include '../../includes/preloader.php';
        ?>
        <div id="main-wrapper">
            <!-- Sidebar Start -->
            <?php
            include '../../includes/aside-vertical.php';
            ?>
            <!--  Sidebar End -->
            <div class="page-wrapper">
                <?php
                include '../../includes/aside-horizontal.php';
                ?>
                <div class="body-wrapper">
                    <div class="container-fluid">
                        <!--  Header Start -->
                        <header class="topbar sticky-top">
                            <div class="with-vertical">
                                <!-- ---------------------------------- -->
                                <!-- Start Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <?php
                                include '../../includes/header.php';
                                ?>
                                <!-- ---------------------------------- -->
                                <!-- End Vertical Layout Header -->
                                <!-- ---------------------------------- -->
                                <!--  Mobilenavbar -->
                                <?php
                                include '../../includes/mobilenavbar.php';
                                ?>
                            </div>
                        </header>
                        <!--  Header End -->
                        <div class="row">
                            <div class="d-flex align-items-stretch">
                                <div class="card">
                                    <div class="card-body wizard-content">
                                        <h4 class="card-title">Evaluacion de la formación</h4>
                                        <p class="card-subtitle mb-3"> Para ser respondido una vez que se concluyó la formación </p>
                                        <form id="evaluacionForm" class="validation-wizard wizard-circle needs-validation" >
                                            <h6>Beneficios de la formación</h6>
                                            <section>
                                                <div class="mb-3">
                                                    <label class="form-label">¿Consideras que hubo algún beneficio a nivel personal después de la formación o acompañamiento?</label>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="beneficioPersonal" id="beneficioSi" value="1" required>
                                                                <label class="form-check-label" for="beneficioSi">Sí</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="beneficioPersonal" id="beneficioNo" value="0" checked required>
                                                                <label class="form-check-label" for="beneficioNo">No</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="beneficiosObtenidos" class="form-label">¿Cuáles fueron los beneficios obtenidos?</label>
                                                    <textarea class="form-control" id="beneficiosObtenidos" name="beneficiosObtenidos" rows="2" disabled required></textarea>

                                                </div>
                                            </section>
                                            <h6>Administración del negocio</h6>
                                            <section>
                                                <div class="mb-3">
                                                    <label for="ventasMensuales" class="form-label">¿Cuál es el monto mensual de tus ventas?</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" id="ventasMensuales" name="ventasMensuales" min="0" value="0" required>
                                                        <span class="input-group-text">.00</span>

                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="gastosMensuales" class="form-label">¿Cuál es el monto mensual de tus gastos/egresos?</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" id="gastosMensuales" name="gastosMensuales" min="0" value="0" required>
                                                        <span class="input-group-text">.00</span>

                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="utilidadesMensuales" class="form-label">¿Cuál es el monto de tus utilidades mensuales?</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" id="utilidadesMensuales" name="utilidadesMensuales" min="0" value="0" required>
                                                        <span class="input-group-text">.00</span>

                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="sueldoMensual" class="form-label">¿Cuál es tu sueldo mensual?</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" id="sueldoMensual" name="sueldoMensual" min="0" value="0" required>
                                                        <span class="input-group-text">.00</span>

                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">¿Es tu negocio la principal fuente de ingresos para ti, a nivel personal?</label>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="ingresoPrincipalPersonal" id="ingresoPrincipalSi" value="1" required>
                                                                <label class="form-check-label" for="ingresoPrincipalSi">Sí</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="ingresoPrincipalPersonal" id="ingresoPrincipalNo" value="0" required>
                                                                <label class="form-check-label" for="ingresoPrincipalNo">No</label>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">¿Es tu negocio la principal fuente de ingresos para tu familia?</label>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="ingresoPrincipalFamiliar" id="ingresoPrincipalFamiliarSi" value="1" required>
                                                                <label class="form-check-label" for="ingresoPrincipalFamiliarSi">Sí</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="ingresoPrincipalFamiliar" id="ingresoPrincipalFamiliarNo" value="0" required>
                                                                <label class="form-check-label" for="ingresoPrincipalFamiliarNo">No</label>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                            <h6>Gestión y optimización del ahorro</h6>
                                            <section>
                                                <div class="mb-3">
                                                    <label class="form-label">¿Tienes el hábito de ahorrar de manera constante y a largo plazo?</label>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="habitoAhorro" id="habitoAhorroSi" value="1" required>
                                                                <label class="form-check-label" for="habitoAhorroSi">Sí</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="habitoAhorro" id="habitoAhorroNo" value="0" required>
                                                                <label class="form-check-label" for="habitoAhorroNo">No</label>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">¿Cuentas con algún sistema de ahorro?</label>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="sistemaAhorro" id="sistemaAhorroSi" value="1" required>
                                                                <label class="form-check-label" for="sistemaAhorroSi">Sí</label>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="sistemaAhorro" id="sistemaAhorroNo" value="0" required>
                                                                <label class="form-check-label" for="sistemaAhorroNo">No</label>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="detallesSistemaAhorro" class="form-label">¿Con qué sistema de ahorro cuentas?</label>
                                                    <input type="text" class="form-control" id="detallesSistemaAhorro" name="detallesSistemaAhorro" disabled required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="objetivoAhorro" class="form-label">¿Cuál es el objetivo principal de tus ahorros?</label>
                                                    <select class="form-select" id="objetivoAhorro" name="objetivoAhorro" disabled required>
                                                        <option value="">Seleccione una opción</option>
                                                        <option value="comprarCosas">Comprar cosas que necesito después</option>
                                                        <option value="lujoPersonal">Darme un lujo o gusto personal</option>
                                                        <option value="prepararmeFuturo">Prepararme para el futuro: imprevistos, enfermedades, urgencias, etc.</option>
                                                        <option value="invertir">Tener una reserva para invertir</option>
                                                    </select>

                                                </div>
                                                <div class="mb-3">
                                                    <label for="ahorroMensual" class="form-label">¿Cuál es el monto aproximado de tus ahorros mensuales?</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text">$</span>
                                                        <input type="number" class="form-control" id="ahorroMensual" name="ahorroMensual" min="0" value="0" disabled required>
                                                        <span class="input-group-text">.00</span>
                                                    </div>
                                                </div>
                                            </section>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        include '../../includes/scriptsjs.php';
        ?>
        <script src="api/evaluacionFormacion.js"></script>
    </body>
</html>