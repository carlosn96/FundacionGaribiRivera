
<div class="card" id="contenido">
    <div class="card-body wizard-content">
        <h4 class="card-title">Ficha de inscripción</h4>
        <p class="mb-3">
            Nos da gusto que estés interesado en los programas de <strong><ins>Promoción y Solidaridad</ins></strong>  
            que se promueven desde la <strong><ins>Fundación Cardenal Garibi Rivera</ins></strong>. 
        </p>
        <h6 class="lh-base mb-3">
            Este formulario nos será de mucha ayuda para poder conocerte un poco mejor y 
            tener información de primera mano sobre la forma en la que podemos contribuir a tu crecimiento personal y profesional.
        </h6>

        <form class="validation-wizard-horizontal wizard-circle needs-validation" id="lineaBaseForm">
            <!-- Información Preliminar -->
            <h6>Información Preliminar</h6>
            <section>
                <div class="mb-4 row align-items-center">
                    <label for="etapaFormacion" class="form-label col-sm-3 col-form-label">Etapa en la que participas</label>
                    <div class="col-sm-9">
                        <input class="form-control" name="etapaFormacion" id="etapaFormacion" readonly="">
                        <input class="form-control" name="idEtapa" id="idEtapa" hidden="">
                    </div>
                </div>
                <div class="row">
                    <!-- ¿Cómo te enteraste de la Fundación? -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">¿Cómo te enteraste de la Fundación?</label>
                        <div id="medioConocimiento"></div>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="otroMedioCheckbox" name="otroMedioConocimiento[]" value="Otro" >
                            <label class="form-check-label" for="otroMedioCheckbox">Otro</label>
                        </div>
                        <input type="text" class="form-control" id="otroMedioConocimiento" name="otroMedioConocimiento[]" placeholder="Por favor, especifique" hidden="" disabled="" required=""/>
                    </div>
                    <!-- Tiempo de formación -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">¿Cuánto tiempo a la semana puedes dedicar para formarte/capacitarte de manera permanente?</label>
                        <div id="tiempoCapacitacion"></div>
                    </div>
                </div>
                <div class="row">
                    <!-- Recurres a la Fundación para -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Recurres a la Fundación para:</label>
                        <div id="razonRecurre">
                        </div>
                        <div class="form-check">
                            <input type="radio" class="form-check-input" id="otraRazonRecurreRadio" name="razonRecurre" value="">
                            <label class="form-check-label" for="otraRazonRecurreRadio">Otra</label>
                        </div>
                        <input type="text" class="form-control" id="otraRazonRecurre" name="otraRazonRecurre" placeholder="Por favor, especifique" hidden="" disabled="" required=""/>
                    </div>
                    <div class="col-md-6">
                        <!-- Crédito solicitarias para -->
                        <div id="solicitaCredito" class="col-md-6 mb-3" hidden>
                            <label class="form-label">El crédito lo <strong><ins>solicitarías</ins></strong> para:</label>
                        </div>
                        <!-- Crédito utilizarias para -->
                        <div id="utilizaCredito" class="col-md-6 mb-3" hidden>
                            <label class="form-label">El crédito lo <strong><ins>utilizarías</ins></strong> para:</label>
                        </div>
                    </div>
                </div>
            </section>
          
        </form>
    </div>
</div>