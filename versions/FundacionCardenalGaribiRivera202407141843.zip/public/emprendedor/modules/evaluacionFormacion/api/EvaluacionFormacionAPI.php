<?php

include_once '../../../../../loader.php';

class EvaluacionFormacionAPI extends API {

    function guardarEvaluacion() {
        $this->data["id_usuario"] = Sesion::obtenerIDUsuarioActual();
        $this->enviarResultadoOperacion(getAdminEvaluacionFormacion()->guardarEvaluacion($this->data));
    }

    function recuperarEvaluacion() {
        $this->enviarRespuesta(getAdminEvaluacionFormacion()->recuperarEvaluacion(Sesion::obtenerIDUsuarioActual()));
    }

    function recuperarCamposFormulario() {
        $admin = getAdminEvaluacionFormacion();
        $this->enviarRespuesta([
            "objetivosAhorro" => $admin->recuperarObjetivosAhorro()
        ]);
    }
}

Util::iniciarAPI(EvaluacionFormacionAPI::class);
