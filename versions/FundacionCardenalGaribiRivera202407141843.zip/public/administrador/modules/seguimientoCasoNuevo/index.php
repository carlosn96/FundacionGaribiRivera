<?php

include_once '../../includes/administradorTemplate.php';
//<script src="../../../assets/libs/datatables.net/js/datatable-advanced.init.js"></script>
renderizarPlantillaEmprendedor(__DIR__, [
    'api/seguimientoCasoNuevo.js'
]);
