<?php

header("Location: index");