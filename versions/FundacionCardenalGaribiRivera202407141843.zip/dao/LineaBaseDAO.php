<?php

class LineaBaseDAO extends DAO {

    private const LISTAR_EMPRENDEDOR_LINEA_BASE = "SELECT * FROM listar_emprendedor_con_linea_base";
    private const BUSCAR_CP = "CALL buscar_codigo_postal(?)";

    public function listarEmprendedoresLineaBase() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_EMPRENDEDOR_LINEA_BASE);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function buscarCodigoPostal($cp) {
        $prep = $this->prepararInstruccion(self::BUSCAR_CP);
        $prep->agregarString($cp);
        return $prep->ejecutarConsultaMultiple();
    }

    public function guardarLineaBase(LineaBase $lineaBase) {
        var_dump($lineaBase->toArray());
        return true;
    }

}
