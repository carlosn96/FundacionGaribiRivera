<?php

class TipoUsuario {

    const ADMINISTRADOR = 2;
    const EMPRENDEDOR = 1;

}
