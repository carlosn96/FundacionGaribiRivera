<?php

/**
 * Description of LineaBase
 *
 * @author JuanCarlos
 */
class LineaBase {

    use Entidad;

    private LineaBasePreliminar $preliminar;
    private int $id;
    private int $idEtapa;

    public function __construct(int $idEtapa, LineaBasePreliminar $preliminar, $id = 0) {
        $this->preliminar = $preliminar;
        $this->id = $id;
        $this->idEtapa = $idEtapa;
    }

    public function getDe(): int {
        return $this->id;
    }

    public function setDe(int $id): void {
        $this->id = $id;
    }

    public function getPreliminar(): LineaBasePreliminar {
        return $this->preliminar;
    }

    public function setPreliminar(LineaBasePreliminar $preliminar): void {
        $this->preliminar = $preliminar;
    }

}
