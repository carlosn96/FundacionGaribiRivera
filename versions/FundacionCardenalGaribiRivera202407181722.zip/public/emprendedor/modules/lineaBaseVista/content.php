<div class="card">
    <div class="card-body">
        <h4 class="card-title">Linea Base</h4>
        <p class="mb-3 card-subtitle">Información proporcionada</p>
        <div>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex active" data-bs-toggle="tab" href="#preliminar" role="tab" aria-selected="true">
                        <span>
                            <i class="ti ti-home-2 fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Preliminar</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#identificacion" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-user fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Identificación</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#domicilio" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-map-2 fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Domicilio</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#socioeconomico" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-wallet fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Socioeconómico</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#negocio" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-home-dollar"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Negocio</span>
                    </a>
                </li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active show p-3" id="preliminar" role="tabpanel">
                    <hr class="m-0">
                    <div class="card-body">
                        <h5 class="card-title mb-0">Información preliminar</h5>
                    </div>
                    <hr class="m-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">¿Cómo te enteraste de la Fundación?</label>
                                    <div class="col-md-9">
                                        <p><span id="preliminar-listaMedioConoceFundacion"></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Recurres a la Fundación para solicitar:</label>
                                    <div class="col-md-9">
                                        <p><span id="preliminar-razonRecurreFundacion-descripcion"></span></p>
                                        <p><span id="preliminar-otraRazonRecurreFundacion"></span></p>
                                        <p><span id="preliminar-solicitaCredito-descripcion"></span></p>
                                        <p><span id="preliminar-utilizaCredito-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Tiempo para capacitarte:</label>
                                    <div class="col-md-9">
                                        <p><span id="preliminar-tiempoDedicaCapacitacion-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane p-3" id="identificacion" role="tabpanel">
                    <hr class="m-0">
                    <div class="card-body">
                        <h5 class="card-title mb-0">Identificación</h5>
                    </div>
                    <hr class="m-0">
                    <div class="card-body">
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Género:</label>
                                    <div class="col-md-9">
                                        <p><span id="identificacion-genero"></span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Edad:</label>
                                    <div class="col-md-9">
                                        <p><span id="identificacion-edad"></span> años</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Estado civil:</label>
                                    <div class="col-md-9">
                                        <p><span id="identificacion-estadoCivil-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Escolaridad:</label>
                                    <div class="col-md-9">
                                        <p><span id="identificacion-escolaridad-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">¿Presenta alguna discapacidad?</label>
                                    <div class="col-md-9">
                                        <p><span id="identificacion-discapacidad"></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane p-3" id="domicilio" role="tabpanel">
                    <hr class="m-0">
                    <div class="card-body">
                        <h3 class="card-title mb-0">Domicilio</h3>
                    </div>
                    <hr class="m-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Dirección:</label>
                                    <div class="col-md-9">
                                        <p>Calle <strong><span id="domicilio-calle"></span></strong>, No. <strong><span id="domicilio-numeroExterior"></span></strong> 
                                            <strong><span id="domicilio-numeroInterior"></span></strong>, 
                                            Entre <strong><span id="domicilio-calleCruce1"></span></strong> 
                                            y <strong><span id="domicilio-calleCruce2"></span></strong>
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Localidad:</label>
                                    <div class="col-md-9">
                                        <p><span id="domicilio-codigoPostal-colonia"></span>, 
                                            <span id="domicilio-municipio-nombre"></span>,
                                            <span id="domicilio-estado"></span>. C.P. <span id="domicilio-codigoPostal-codigo"></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/row-->
                        <div class="row">
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Comunidad Parroquial:</label>
                                    <div class="col-md-9">
                                        <p><span id="domicilio-comunidadParroquial-nombre"></span></p>
                                        <p>Decanato: <span id="domicilio-comunidadParroquial-decanato"></span></p>
                                        <p>Vicaria: <span id="domicilio-comunidadParroquial-vicaria"></span></p>
                                    </div>
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                    </div>
                </div>
                <div class="tab-pane p-3" id="socioeconomico" role="tabpanel">  
                    <hr class="m-0">
                    <div class="card-body">
                        <h5 class="card-title mb-0">Socioeconómico</h5>
                    </div>
                    <hr class="m-0">
                    <div class="card-body">
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Cantidad Dependientes:</label>
                                    <div class="col-md-9">
                                        <p><span id="socioeconomico-cantidadDependientes"></span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Ocupación Actual:</label>
                                    <div class="col-md-9">
                                        <p><span id="socioeconomico-ocupacionActual-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="form-label text-end col-md-3">Ingreso Mensual:</label>
                                    <div class="col-md-9">
                                        <p><span id="socioeconomico-ingresoMensual-descripcion"></span></p>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="tab-pane p-3" id="negocio" role="tabpanel">
                    <div id="infoNegocio">
                        <hr class="m-0">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <h5 class="card-title  col-md-3 mb-0">Negocio: </h5>
                                <div class="col-md-9">
                                    <span id="negocio-nombre"></span>
                                </div>
                            </div>
                            <div class="row align-items-center">
                                <label class="form-label col-md-3 col-form-label">Teléfono:</label>
                                <div class="col-md-9">
                                    <span id="negocio-telefono"></span>
                                </div>
                            </div>
                        </div>
                        <hr class="m-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Dirección:</label>
                                        <div class="col-md-9">
                                            <p>Calle <strong><span id="negocio-calle"></span></strong>, No. <strong><span id="negocio-numExterior"></span></strong>
                                                (<strong><span id="negocio-numeroInterior"></span></strong>), 
                                                Entre <strong><span id="negocio-calleCruce1"></span></strong> 
                                                y <strong><span id="negocio-calleCruce2"></span></strong>
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Localidad:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-codigoPostal-colonia"></span>, 
                                                <span id="negocio-municipio-nombre"></span>,
                                                <span id="negocio-estado"></span>. C.P. <span id="negocio-codigoPostal-codigo"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Antigüedad:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-antiguedad"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Cantidad de Empleados:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-cantEmpleados"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Otro Giro:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-otroGiro"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Giro:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-giro-descripcion"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Actividad Principal:</label>
                                        <div class="col-md-9">
                                            <p><span id="negocio-actividadPrincipal"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr class="m-0">
                        <div class="card-body">
                            <h5 class="card-title mb-0">Análisis de Negocio</h5>
                        </div>
                        <hr class="m-0">
                        <div class="card-body">
                            <!-- Análisis de Negocio -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Problemas del Negocio:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-problemasNegocio"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Registra Entrada y Salida:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-registraEntradaSalida"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Asigna Sueldo:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-asignaSueldo"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Conoce Utilidades:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-conoceUtilidades"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Identifica Competencia:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-identificaCompetencia"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Quién es la Competencia:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-quienCompetencia"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Clientes del Negocio:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-clientesNegocio"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Ventajas del Negocio:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-ventajasNegocio"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Conoce Productos de Mayor Utilidad:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-conoceProductosMayorUtilidad"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Porcentaje de Ganancias:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-porcentajeGanancias"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Ahorro:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-ahorro"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Cuánto Ahorro:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-cuantoAhorro"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Razones No Ahorro:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-razonesNoAhorro"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Conoce Punto de Equilibrio:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-conocePuntoEquilibrio"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Separa Gastos:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-separaGastos"></span></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="form-label text-end col-md-3">Elabora Presupuesto:</label>
                                        <div class="col-md-9">
                                            <p><span id="analisisNegocio-elaboraPresupuesto"></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="msgNoNegocio" hidden="">
                        <div class="alert alert-warning text-warning alert-dismissible fade show" role="alert">
                            <strong>Sin información del negocio</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



