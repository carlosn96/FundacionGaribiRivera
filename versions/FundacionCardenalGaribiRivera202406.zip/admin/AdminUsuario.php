<?php

class AdminUsuario {

    private $dao;

    public function __construct() {
        $this->dao = new UsuarioDAO();
    }

    public function existeCorreo($correo) {
        return $this->dao->existeCorreo($correo);
    }

    public function guardarCodigoRestablecer($correo, $codigo) {
        return $this->dao->guardarCodigoRestablecer($correo, $codigo);
    }

    // Método para insertar un nuevo usuario en la base de datos
    public function insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario = 1) {
        return $this->dao->insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario = 1);
    }

    public function validarCodigoVerificacion($correo, $codigo) {
        return $this->dao->validarCodigoVerificacion($correo, $codigo);
    }

    public function cambiarContrasena($correo, $contrasena) {
        return $this->dao->cambiarContrasena($correo, $contrasena);
    }

    public function buscarUsuarioPorCorreoContrasena($correo, $contrasena) {
        return $this->dao->buscarUsuarioPorCorreoContrasena($correo, $contrasena);
    }

    public function actualizarTokenUsuario($id, $token) {
        // Obtener la hora actual del servidor
        return $this->dao->actualizarTokenUsuario($id, $token);
    }

    public function eliminarTokenExpiradoUsuarioActivo($id) {
        return $this->dao->eliminarTokenExpiradoUsuarioActivo($id);
    }

}
