<?php

class PreparedStatmentArgs {

    private const ALLOWED_TYPES = ["s", "i", "d", "b"];
    private const TYPE_INDEX = 0;
    private const DATA_INDEX = 1;

    private $data;
    private $blob;

    function __construct() {
        $this->data = array();
        $this->blob = array();
    }

    function add($type, $val) {
        if (!in_array($type, self::ALLOWED_TYPES)) {
            throw new Exception("Tipo de dato no permitido");
        }
        array_push($this->data, [$type, $val]);
    }
    
    function add_blob(int $arg_number, $data) {
        $this->blob["arg_number"] = $arg_number;
        $this->data["data"] = $data;
    }

    function get(): array {
        return $this->data;
    }

    function compile(mysqli_stmt &$stmt) {
        //$stmt = $this->preparar_instruccion($instruccion);
        $params = "";
        $data = [];
        foreach ($this->data as $value) {
            $params .= $value[self::TYPE_INDEX];
            array_push($data, $value[self::DATA_INDEX]);
        }
        // var_dump($instruccion);
        //  var_dump($params);
        //  var_dump($data); 
        $stmt->bind_param($params, ...$data);
        if (count($this->blob)>0) {
            //var_dump($blob);
            $stmt->send_long_data($this->blob["arg_number"], $this->blob["data"]);
        }
        //echo "ERROR: ".$stat->error;
        
    }

}
