<?php

class UsuarioDAO extends DAO {

    public function existeCorreo($correo) {
        $stmt = $this->preparar_instruccion("SELECT * FROM usuarios WHERE correo_electronico = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        return $result->num_rows > 0;
    }

    public function guardarCodigoRestablecer($correo, $codigo) {
        $stmt = $this->preparar_instruccion("UPDATE usuarios SET codigo_restablecer = ? WHERE correo_electronico = ?");
        $stmt->bind_param("ss", $codigo, $correo);
        $resultado = $stmt->execute();
        $stmt->close();
        return $resultado;
    }

    public function validarCodigoVerificacion($correo, $codigo) {
        $stmt = $this->preparar_instruccion("SELECT * FROM usuarios WHERE correo_electronico = ? AND codigo_restablecer = ?");
        $stmt->bind_param("ss", $correo, $codigo);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        return $result->num_rows > 0;
    }

    public function cambiarContrasena($correo, $contrasena) {
        $sql = "UPDATE usuarios SET contrasena = ? WHERE correo_electronico = ?";
        $stmt = $this->preparar_instruccion($sql);
        $stmt->bind_param("ss", $contrasena, $correo);
        return $stmt->execute();
    }

    public function insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario = 1) {
        $sql = "INSERT INTO usuarios (nombre, apellidos, correo_electronico, numero_celular, contrasena, id_tipo_usuario) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->preparar_instruccion($sql);
        if (!$stmt) {
            die("Error en la preparación de la consulta: " . $this->conn->error);
        }
        $stmt->bind_param("sssssi", $nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario);
        return $stmt->execute();
    }

    public function buscarUsuarioPorCorreoContrasena($correo, $contrasena) {
        $sql = "SELECT * FROM usuarios WHERE correo_electronico = ? AND contrasena = ?";
        $stmt = $this->preparar_instruccion($sql);
        $stmt->bind_param("ss", $correo, $contrasena);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return false;
        }
    }

    public function actualizarTokenUsuario($id, $token) {
        // Obtener la hora actual del servidor
        $sql = "UPDATE usuarios SET token = ?, tiempo_expiracion = NOW() + INTERVAL 1 MINUTE WHERE id = ?";
        $stmt = $this->preparar_instruccion($sql);
        if (!$stmt) {
            die("Error en la preparación de la consulta: " . $this->conn->error);
        }
        $stmt->bind_param("si", $token, $id);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function eliminarTokenExpiradoUsuarioActivo($id) {
        $sql = "UPDATE usuarios SET token = NULL, tiempo_expiracion = NULL WHERE id = ? AND tiempo_expiracion < NOW()";
        $stmt = $this->preparar_instruccion($sql);
        if (!$stmt) {
            die("Error en la preparación de la consulta: " . $this->conn->error);
        }
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            return true; // Si la actualización fue exitosa, devolvemos true
        } else {
            return false; // Si hubo algún error, devolvemos false
        }
    }

}
