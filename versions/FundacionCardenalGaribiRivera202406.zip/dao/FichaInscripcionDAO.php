<?php

class FichaInscripcionDAO extends DAO {
    
}
