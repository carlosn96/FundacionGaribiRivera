<?php

class Sesion {

    private const ROOT_SGB = "GestionDeBeneficiarios/";
    private const RECUPERACION_APOYOS = self::ROOT_SGB . "recuperacionApoyos/";
    private const TRABAJO_SOCIAL = self::ROOT_SGB . "trabajoSocial/";
    private const PROYECTOS = self::ROOT_SGB . "proyectos/";
    private const ADMINISTRACION = "administracionGeneral/";
    private const EMPRENDEDOR = "emprendedor" . DIRECTORY_SEPARATOR;
    public const INDEX = ROOT_APP;

    public static function setUsuarioActual($usuario) {
        $_SESSION["usuario"] = $usuario;
    }

    public static function setToken($token) {
        // Almacenar el token y el tiempo de expiración en la sesión del usuario
        $_SESSION['token']["code"] = $token;
        // Establecer el tiempo de expiración (1 minuto en el futuro)
        $_SESSION['token']['tiempoExpiracion'] = date('Y-m-d H:i:s', strtotime('+1 minute'));
    }

    public static function getToken() {
        return $_SESSION['token'] ?? null;
    }

//    public static function establecer_usuario_actual(Usuario $usuario): void {
//        $_SESSION["usuario"] = serialize($usuario);
//    }

    public static function obtenerUsuarioActual() {
        return $_SESSION["usuario"] ?? null;
    }

    public static function cerrar() {
        unset($_SESSION);
        session_destroy();
    }

    public function actualizar($usuario) {
        self::setUsuarioActual($usuario);
    }

    private static function verificarURLSesion() {
        $usuario = self::obtenerUsuarioActual();
        switch (is_null($usuario) ? "" : $usuario["id_tipo_usuario"]) {
            case TipoUsuario::EMPRENDEDOR:
                $url = self::EMPRENDEDOR;
                break;
            case TipoUsuario::ADMINISTRADOR:
                $url = self::ADMINISTRACION;
                break;
            default:
                $url = self::INDEX;
        }
        return $url;
    }

    public static function info(): array {
        $info["usuario"] = self::obtenerUsuarioActual();
        $info["url"] = self::verificarURLSesion();
        $info["token"] = self::getToken();
        //$info["root_app"] = self::INDEX;
        return $info;
    }

}
