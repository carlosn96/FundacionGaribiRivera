<?php

abstract class API {

    private $case;
    protected $data;

    function __construct($case, $data) {
        $this->set_case($case);
        $this->set_data(Util::separaCamposFomulario($data));
        $this->resolver_peticion();
    }

    protected function resolver_peticion() {
        $case = $this->case;
        if (method_exists($this, $case)) {
            $this->$case();
        } else {
            $this->enviar_respuesta_str("sin respuesta");
        }
    }

    private function codificar_respuesta($respuesta) {
        echo json_encode($respuesta);
    }

    protected function enviarRespuesta(array $respuesta) {
        $this->codificar_respuesta($respuesta);
    }

    protected function enviar_respuesta_str(string $respuesta) {
        $this->codificar_respuesta(["response" => $respuesta]);
    }

    function get_case() {
        return $this->case;
    }

    function set_case($case): void {
        $this->case = $case;
    }

    function set_data($data): void {
        $this->data = $data;
    }

}
