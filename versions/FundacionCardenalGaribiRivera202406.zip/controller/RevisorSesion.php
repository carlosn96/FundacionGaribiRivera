<?php

include_once '../loader.php';

class RevisorSesion extends API {

    public function cerrarSesion() {
        Sesion::cerrar();
        $this->enviarRespuesta(["sesionCerrada" => is_null(Sesion::obtenerUsuarioActual())]);
    }

    public function verificarSesion() {
        $info = Sesion::info();
        $this->enviarRespuesta([
            "sesionActiva" => isset($info["usuario"]) && isset($info["token"]) && $this->esSesionValidaPorTiempo($info["token"]),
            "url" => $info["url"],
            "token" => $info["token"]
        ]);
    }

    private function esSesionValidaPorTiempo($token) {
        if (!($sesionActiva = $token["tiempoExpiracion"] > time())) {
            Sesion::cerrar();
        }
        return $sesionActiva;
    }

}

Util::iniciarAPI("RevisorSesion");
