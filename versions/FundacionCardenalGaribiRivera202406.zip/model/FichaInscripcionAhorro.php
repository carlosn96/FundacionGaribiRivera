<?php

class FichaInscripcionAhorro extends Objecto {

    private $lleva_registro;
    private $venta_mensual;
    private $gasto_mensual;
    private $utilidad_mensual;
    private $sueldo_mensual;
    private $ahorro_permanente;
    private $sistema_ahorro;
    private $objetivo_ahorro;
    private $monto_ahorro_mensual;
    private $ahorro_negocio;

    function __construct($lleva_registro, $venta_mensual, $gasto_mensual, $utilidad_mensual, $sueldo_mensual, $ahorro_permanente, $sistema_ahorro, $objetivo_ahorro, $monto_ahorro_mensual, $ahorro_negocio) {
        $this->lleva_registro = $lleva_registro;
        $this->venta_mensual = $venta_mensual;
        $this->gasto_mensual = $gasto_mensual;
        $this->utilidad_mensual = $utilidad_mensual;
        $this->sueldo_mensual = $sueldo_mensual;
        $this->ahorro_permanente = $ahorro_permanente;
        $this->sistema_ahorro = $sistema_ahorro;
        $this->objetivo_ahorro = $objetivo_ahorro;
        $this->monto_ahorro_mensual = $monto_ahorro_mensual;
        $this->ahorro_negocio = $ahorro_negocio;
    }

    function getLleva_registro() {
        return $this->lleva_registro;
    }

    function getVenta_mensual() {
        return $this->venta_mensual;
    }

    function getGasto_mensual() {
        return $this->gasto_mensual;
    }

    function getUtilidad_mensual() {
        return $this->utilidad_mensual;
    }

    function getSueldo_mensual() {
        return $this->sueldo_mensual;
    }

    function getAhorro_permanente() {
        return $this->ahorro_permanente;
    }

    function getSistema_ahorro() {
        return $this->sistema_ahorro;
    }

    function getObjetivo_ahorro() {
        return $this->objetivo_ahorro;
    }

    function getMonto_ahorro_mensual() {
        return $this->monto_ahorro_mensual;
    }

    function getAhorro_negocio() {
        return $this->ahorro_negocio;
    }

    function setLleva_registro($lleva_registro): void {
        $this->lleva_registro = $lleva_registro;
    }

    function setVenta_mensual($venta_mensual): void {
        $this->venta_mensual = $venta_mensual;
    }

    function setGasto_mensual($gasto_mensual): void {
        $this->gasto_mensual = $gasto_mensual;
    }

    function setUtilidad_mensual($utilidad_mensual): void {
        $this->utilidad_mensual = $utilidad_mensual;
    }

    function setSueldo_mensual($sueldo_mensual): void {
        $this->sueldo_mensual = $sueldo_mensual;
    }

    function setAhorro_permanente($ahorro_permanente): void {
        $this->ahorro_permanente = $ahorro_permanente;
    }

    function setSistema_ahorro($sistema_ahorro): void {
        $this->sistema_ahorro = $sistema_ahorro;
    }

    function setObjetivo_ahorro($objetivo_ahorro): void {
        $this->objetivo_ahorro = $objetivo_ahorro;
    }

    function setMonto_ahorro_mensual($monto_ahorro_mensual): void {
        $this->monto_ahorro_mensual = $monto_ahorro_mensual;
    }

    function setAhorro_negocio($ahorro_negocio): void {
        $this->ahorro_negocio = $ahorro_negocio;
    }
}
