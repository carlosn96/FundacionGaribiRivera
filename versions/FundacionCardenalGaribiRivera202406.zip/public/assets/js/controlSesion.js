
$(document).ready(function () {
    verificarSesion();
});

function logout() {
    crearPeticion("../../../../controller/RevisorSesion.php", {"case": "cerrarSesion"}, function (res) {
        if (res.sesionCerrada) {
            refresh();
        }
    });
}

function verificarSesion() {
    print("Validando sesión ...");
    crearPeticion("../../../../controller/RevisorSesion.php", {"case": "verificarSesion"}, function (res) {
        print(res);
        print(window.location.pathname);

        const inicioSesionPath = "/FundacionCardenalGaribiRivera202405/public/index/modules/inicio/";
        const isSesionActiva = res.sesionActiva;
        const userRedirectUrl = res.url;
        const currentPath = window.location.pathname;

        if (currentPath.endsWith("index/modules/inicio/")) {
            // Estamos en la página de inicio de sesión
            if (isSesionActiva) {
                // Si la sesión está activa, redirigimos al módulo correspondiente solo si no estamos ya en esa página
                if (!currentPath.endsWith(userRedirectUrl)) {
                    redireccionar("../../../" + userRedirectUrl);
                }
            }
            // Si la sesión no está activa, no hacemos nada y se queda en el login
        } else {
            // No estamos en la página de inicio de sesión
            if (!isSesionActiva) {
                // Si la sesión no está activa, redirigimos al inicio de sesión
                if (!currentPath.endsWith(inicioSesionPath)) {
                    redireccionar(inicioSesionPath);
                }
            }
            // Si la sesión está activa, no hacemos nada y se queda en el módulo actual
        }
    });
}


