<?php
class UsuarioDAO {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

   
}
?>
