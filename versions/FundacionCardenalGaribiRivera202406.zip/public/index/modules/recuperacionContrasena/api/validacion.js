document.addEventListener('DOMContentLoaded', function () {
    $('#formValidarCodigo').submit(function (event) {
        event.preventDefault();
        var codigo = $('#codigo').val();

        $.ajax({
            type: 'POST',
            url: 'api/RecuperarCuentaAPI.php',
            dataType: 'json',
            data: {case: "validarCodigoSeguridad", data: "codigo=" + codigo},
            success: function (response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: response.message,
                        showConfirmButton: false,
                        timer: 2000
                    }).then(function () {
                        window.location.href = 'restablecer.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.message
                    });
                }
            },
            error: function (xhr, status, error) {
                console.error('Error en la solicitud:', xhr.responseText);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Ocurrió un error al procesar la solicitud '
                });
            }
        });
    });
});
