<?php
require_once "funciones.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["correo_electronico"])) {
    $correo_destinatario = $_POST["correo_electronico"];

    // Verificar si el correo existe en la base de datos (puedes implementar esta lógica si lo necesitas)
    if (existeCorreo($correo_destinatario)) {
        // Generar y guardar token en la base de datos para este usuario
        $token = generarToken();
        // Aquí deberías tener una función que guarde el token en la base de datos

        // Comprobar si el token se ha guardado correctamente
        if ($guardado) {
            // Enviar correo electrónico con el token
            $asunto = "Restablecer tu contraseña";
            $mensaje = "Para restablecer tu contraseña, ingresa el siguiente código:\n\n$token\n";
            if (enviarCorreo($correo_destinatario, $asunto, $mensaje)) {
                echo json_encode(['success' => true, 'message' => 'Correo enviado con éxito.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al enviar el correo.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al generar y guardar el token en la base de datos.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'El correo proporcionado no existe en la base de datos.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Error: No se recibieron datos válidos.']);
}
?>
