<?php

include_once '../../../../../loader.php';
require_once "PHPMailer/src/PHPMailer.php";
require_once "PHPMailer/src/SMTP.php";
require_once "PHPMailer/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class RecuperarCuentaAPI extends API {

    function validarCodigoSeguridad() {
        $adminUsuario = new AdminUsuario;
        $codigo = $this->data['codigo'];
        // Verificar si se ha guardado un correo electrónico en la sesión
        if (!isset($_SESSION['correoElectronico'])) {
            $this->enviarRespuesta(['success' => false, 'message' => 'Correo no está en sesión']);
        }
        $correo = $_SESSION['correoElectronico'];
        // Verificar que el código corresponda al correo en sesión
        if ($adminUsuario->validarCodigoVerificacion($correo, $codigo)) {
            $this->enviarRespuesta(['success' => true, 'message' => 'Código válido.']);
        } else {
            $this->enviarRespuesta(['success' => false, 'message' => 'Código inválido.']);
        }
    }

    function recuperarCuenta() {
        $correoDestino = $this->data['correo_electronico'];
        $_SESSION['correoElectronico'] = $correoDestino;
        $adminUsuario = new AdminUsuario;
        if ($adminUsuario->existeCorreo($correoDestino)) {
            $codigo = bin2hex(random_bytes(4));
            if ($adminUsuario->guardarCodigoRestablecer($correoDestino, $codigo)) {
                if ($this->enviarCorreo($correoDestino, $codigo)) {
                    $respuesta = ['success' => true, 'message' => 'El correo de recuperación se ha enviado con éxito'];
                } else {
                    $respuesta = ['success' => false, 'message' => 'Error al enviar el correo de recuperación'];
                }
            } else {
                $respuesta = ['success' => false, 'message' => 'Error al guardar el código en la base de datos'];
            }
        } else {
            $respuesta = ['success' => false, 'message' => 'El correo no existe'];
        }
        $this->enviarRespuesta($respuesta);
    }

    function restablecerContrasenia() {
        if (isset($_SESSION['correoElectronico']) && isset($this->data['contrasena']) && isset($this->data['confirmar_contrasena'])) {
            $correoElectronico = $_SESSION['correoElectronico'];
            $nuevaContrasena = $this->data['contrasena'];
            $confirmarContrasena = $this->data['confirmar_contrasena'];
            // Verificar que las contraseñas coincidan
            if ($nuevaContrasena !== $confirmarContrasena) {
                echo json_encode(['success' => false, 'message' => 'Las contraseñas no coinciden']);
                exit();
            }
            // Cambiar la contraseña utilizando el método del DAO
            if ((new AdminUsuario())->cambiarContrasena($correoElectronico, $nuevaContrasena)) {
                echo json_encode(['success' => true, 'message' => 'Contraseña cambiada correctamente']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al cambiar la contraseña']);
            }
        } else {
            // Datos incompletos, responder con error
            http_response_code(400);
            echo json_encode(['error' => 'Datos incompletos']);
        }
    }

    function generarTokenSesion() {
        return bin2hex(random_bytes(16));
    }

    function generarToken($longitud = 4) {
        return bin2hex(random_bytes($longitud));
    }

    function generarCodigoVerificacion($longitud = 3) {
        return substr(str_shuffle("0123456789"), 0, $longitud);
    }

    private function enviarCorreo($destinatario, $codigo) {
        $from_email = "soporte@fundaciongaribirivera.com";
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = EMAIL_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = EMAIL_USER;
            $mail->Password = EMAIL_PASSWORD;
            $mail->SMTPSecure = 'tls';
            $mail->Port = EMAIL_PORT;
            $mail->setFrom($from_email, 'Fundación Cardenal Garibi Rivera - Soporte');
            $mail->addAddress($destinatario);
            $mail->Subject = "Código de Verificación para Restablecer Contraseña";
            // Leer la plantilla del archivo
            $template = file_get_contents('../assets/email_template.html');
            // Reemplazar las variables en la plantilla
            $body = str_replace('{year}', date('Y'), str_replace('{codigo}', $codigo, $template));
            $mail->isHTML(true);
            $mail->Body = $body;
            $mail->AltBody = "Estimado usuario:\n\nHa solicitado restablecer su contraseña. Por favor, use el siguiente código para completar el proceso:\n\nCódigo: $codigo\n\nSi no solicitó este cambio, por favor, ignore este correo electrónico.\n\n" . date('Y') . " Fundación Cardenal Garibi Rivera. Todos los derechos reservados.\nEste es un mensaje generado automáticamente, por favor no responda a este correo.\nVisite nuestro sitio web: www.fundaciongaribirivera.com";
            // Adjuntar la imagen
            $mail->addEmbeddedImage('../assets/logoLight.png', 'logo_cid');
            $mail->CharSet = 'UTF-8';
            $mail->Encoding = 'base64';
            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

}

Util::iniciarAPI("RecuperarCuentaAPI");
