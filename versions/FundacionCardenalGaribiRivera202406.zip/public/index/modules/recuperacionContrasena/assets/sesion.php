<?php

// Verificar si se ha enviado un correo electrónico anteriormente
if (isset($_SESSION['correoElectronico'])) {
    $correoElectronico = $_SESSION['correoElectronico'];
} else {
    $correoElectronico = '';
    header("Location: ../");
}