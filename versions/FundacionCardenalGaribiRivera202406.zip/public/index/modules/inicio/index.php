<!DOCTYPE html>
<html lang="es" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">

    <head>
        <!-- Head -->
        <?php
        include_once '../../includes/head.php';
        ?>
    </head>

    <body>
        <!-- Preloader y Overlay con Spinner -->
        <?php
        include_once '../../includes/overlay.php';
        ?>
        <div id="main-wrapper" class="p-0 bg-white">
            <div class="auth-login position-relative overflow-hidden d-flex align-items-center justify-content-center px-7 px-xxl-0 rounded-3 h-n20">
                <div class="auth-login-shape position-relative w-100">
                    <div class="auth-login-wrapper card mb-0 container position-relative z-1 h-100 max-h-770"
                         data-simplebar>
                        <div class="card-body glass-effect">
                            <div class="card-body">
                                <a href="https://fundaciongaribirivera.com/" class="">
                                    <img src="../../../assets/images/logos/logo-dark.svg" class="light-logo" alt="Logo-Dark" />
                                </a>
                                <div class="row align-items-center justify-content-around pt-6 pb-5">
                                    <div class="col-lg-6 col-xl-5 d-none d-lg-block">
                                        <div class="text-center text-lg-start">
                                            <img src="../../../assets/images/backgrounds/IMGS.svg" alt="" class="img-fluid" />
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-xl-5">
                                        <h2 class="mb-6 fs-8 fw-bolder">Iniciar Sesión</h2>
                                        <form id="loginForm">
                                            <div class="mb-3">
                                                <label for="correo" class="form-label">Correo Electrónico:</label>
                                                <input type="email" class="form-control" id="correo" name="correo" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="contrasena" class="form-label">Contraseña:</label>
                                                <input type="password" class="form-control" id="contrasena"
                                                       name="contrasena" required>
                                            </div>
                                            <div class="d-flex justify-content-between mb-3">
                                                <a class="text-primary" href="../recuperacionContrasena/">¿Olvidaste tu contraseña?</a>
                                            </div>
                                            <input type="submit" class="btn btn-primary w-100 mb-3" value="Entrar">
                                            <div class="d-flex justify-content-between">
                                                <p class="mb-0">¿No tienes cuenta?</p>
                                                <a class="text-primary fw-bold ms-2" href="../crearCuenta/">Crear una cuenta</a>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Import Js Files -->
        <?php
        include_once '../../includes/scripts.php';
        ?>
        <script src="../../../assets/js/controlSesion.js"></script>
        <!-- Script -->
        <script src="api/inicio.js"></script>
    </body>

</html>