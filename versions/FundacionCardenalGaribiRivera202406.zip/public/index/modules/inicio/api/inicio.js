$(document).ready(function () {
    $('#loginForm').submit(function (event) {
        event.preventDefault();
        var correo = $('#correo').val();
        var contrasena = $('#contrasena').val();
        crearPeticion('api/IndexAPI.php', {
            case: 'login',
            data: "correo=" + correo + "&contrasena=" + contrasena
        }, function (response) {
            console.log(response);
            if (response.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Inicio de sesión exitoso!',
                    showConfirmButton: false,
                    timer: 1500
                }).then(function () {
                    refresh();
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Inicio de sesión fallido',
                    text: 'Verifica tu correo electrónico y contraseña.',
                    showConfirmButton: false,
                    timer: 3000
                });
            }
        }, function (xhr, status, error) {
            console.log(xhr);
            console.error('Error en la solicitud:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error en la solicitud',
                text: 'Hubo un problema al procesar la respuesta del servidor. Inténtalo de nuevo más tarde.'
            });
        }
        );
    });
});