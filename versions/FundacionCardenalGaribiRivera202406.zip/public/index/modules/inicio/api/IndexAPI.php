<?php

include_once '../../../../../loader.php';

class IndexAPI extends API {

    private $adminUsuario;

    function __construct($case, $data) {
        $this->adminUsuario = new AdminUsuario();
        parent::__construct($case, $data);
    }

    public function login() {
        $correo = $this->data["correo"];
        $contrasena = $this->data["contrasena"];

        $usuario = $this->adminUsuario->buscarUsuarioPorCorreoContrasena($correo, $contrasena);

        if ($usuario) {
            // Generar un token único
            $token = bin2hex(random_bytes(16)); // Genera un token de 32 caracteres hexadecimal
            // Actualizar la entrada del usuario en la base de datos con el nuevo token y tiempo de expiración
            $this->adminUsuario->actualizarTokenUsuario($usuario['id'], $token);
            // Eliminar el token expirado del usuario si existe
            $this->adminUsuario->eliminarTokenExpiradoUsuarioActivo($usuario['id']);
            Sesion::setUsuarioActual($usuario);
            Sesion::setToken($token);
            $this->enviarRespuesta(['success' => true, 'infoSesion' => Sesion::info()]);
        } else {
            $this->enviarRespuesta(['success' => false, 'error' => 'Credenciales incorrectas']);
        }
    }

}

Util::iniciarAPI("IndexAPI");
