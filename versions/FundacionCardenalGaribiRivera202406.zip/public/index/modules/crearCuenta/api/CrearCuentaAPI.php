<?php

// Incluir el archivo de configuración y el DAO
require_once '../../../../../loader.php';

class CrearCuentaAPI extends API {

    function preregistro() {
        $_SESSION["preregistro"] = $this->data;
        $this->enviarRespuesta(['success' => true]);
    }

    function crearNuevaCuenta() {
        // Obtener los datos del formulario
        $nombre = $this->data['nombre'];
        $apellidos = $this->data['apellidos'];
        $correo = $this->data['correo'];
        $numero_celular = $this->data['numero_celular'];
        $contrasena = $this->data['contrasena'];
        $id_tipo_usuario = TipoUsuario::EMPRENDEDOR; // Definir el valor del id_tipo_usuario como "1"
        // Enviar respuesta en formato JSON
        if ((new AdminUsuario())->insertarUsuario($nombre, $apellidos, $correo, $numero_celular, $contrasena, $id_tipo_usuario)) {
            $this->enviarRespuesta(['success' => true]);
        } else {
            $this->enviarRespuesta(['success' => false]);
        }
    }

}

Util::iniciarAPI("CrearCuentaAPI");
