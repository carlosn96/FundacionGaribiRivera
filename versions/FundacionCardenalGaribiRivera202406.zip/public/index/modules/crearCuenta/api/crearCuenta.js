$(document).ready(function () {
    // Captura el evento clic del botón 'submitBtn'
    $('#registroForm').submit(function (event) {
        event.preventDefault(); // Evita que se realice la acción predeterminada del botón
        // Realiza una solicitud AJAX para enviar los datos del formulario al servidor
        crearPeticion(
                'api/CrearCuentaAPI.php',
                {case: "preregistro", data: $(this).serialize()},
                function (response) {
                    // Maneja la respuesta del servidor
                    if (response.success) {
                        // Si la respuesta indica éxito, muestra un mensaje de éxito
                        Swal.fire({
                            icon: 'success',
                            title: 'Se envio un código de verificación al correo ingresado!',
                            showConfirmButton: false,
                            timer: 2000
                        }).then(function () {
                            redireccionar("validacion.php");
                        });
                    } else {
                        // Si la respuesta indica un error, muestra un mensaje de error
                        Swal.fire({
                            icon: 'error',
                            title: 'Error en el registro',
                            text: 'Hubo un problema al registrar la cuenta. Por favor, inténtalo de nuevo más tarde.',
                            showConfirmButton: false,
                            timer: 3000
                        });
                    }
                },
                function (xhr, status, error) {
                    // Maneja los errores de la solicitud AJAX
                    console.error('Error en la solicitud:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error en la solicitud',
                        text: 'Hubo un problema al procesar la solicitud. Por favor, inténtalo de nuevo más tarde.'
                    });
                }
        );
    });
});
