<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">
    <head>
        <!-- Head -->
        <?php
        include_once '../../includes/head.php';
        ?>
    </head>
    <body>
        <!-- Preloader y Overlay con Spinner -->
        <?php
        include_once '../../includes/overlay.php';
        ?>
        <div id="main-wrapper" class="p-0 bg-white">
            <div class="auth-login position-relative overflow-hidden d-flex align-items-center justify-content-center px-7 px-xxl-0 rounded-3 h-n20">
                <div class="auth-login-shape position-relative w-100">
                    <div class="auth-login-wrapper card mb-0 container position-relative z-1 h-100 max-h-770" data-simplebar>
                        <div class="card-body">
                            <a href="#" class="">
                                <img src="../../../assets/images/logos/logo-dark.svg" class="light-logo" alt="Logo-Dark" />
                            </a>
                            <div class="row align-items-center justify-content-around pt-6 pb-5">
                                <div class="col-lg-6 col-xl-5 d-none d-lg-block">
                                    <div class="text-center text-lg-start">
                                        <img src="../../../assets/images/backgrounds/fondoRegistro.png" alt="" class="img-fluid" />
                                    </div>
                                </div>
                                <div class="col-lg-6 col-xl-5">
                                    <h2 class="mb-6 fs-8 fw-bolder">Registro</h2>
                                    <form id="registroForm">
                                        <div class="mb-7">
                                            <label for="nombre" class="form-label text-dark fw-bold">Nombre:</label>
                                            <input type="text" class="form-control py-6" id="nombre" name="nombre" placeholder="" aria-label="nombre" required />
                                        </div>
                                        <div class="mb-7">
                                            <label for="apellidos" class="form-label text-dark fw-bold">Apellidos:</label>
                                            <input type="text" class="form-control py-6" id="apellidos" name="apellidos" placeholder="" aria-label="apellidos" required />
                                        </div>
                                        <div class="mb-7">
                                            <label for="correo" class="form-label text-dark fw-bold">Correo electrónico:</label>
                                            <input type="email" class="form-control py-6" id="correo" name="correo" aria-describedby="emailHelp" required />
                                        </div>
                                        <div class="mb-9">
                                            <label for="numero_celular" class="form-label text-dark fw-bold">Número celular:</label>
                                            <input type="text" class="form-control py-6" id="numero_celular" name="numero_celular" required />
                                        </div>
                                        <div class="mb-9">
                                            <label for="contrasena" class="form-label text-dark fw-bold">Contraseña:</label>
                                            <input type="password" class="form-control py-6" id="contrasena" name="contrasena" required />
                                        </div>
                                        <!-- Cambiamos el tipo de botón a 'button' en lugar de 'submit' -->
                                        <button type="submit" id="submitBtn" class="btn btn-primary w-100 mb-7 rounded-pill">Registrarme</button>
                                    </form>
                                    <div class="d-flex align-items-center">
                                        <p class="fs-3 mb-0 fw-medium">
                                            ¿Ya tienes cuenta?
                                        </p>
                                        <a class="text-primary fw-bold ms-2 fs-3" href="../inicio/">Inicia sesión</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        include_once '../../includes/scripts.php';
        ?>
        <script src="api/crearCuenta.js"></script>
    </body>

</html>