
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include_once '../../includes/head.php';
        ?>
    </head>
    <body>
        <h1>Perfil del Emprendedor</h1>
        <div id="info"></div>
        <!-- Import Js Files -->
        <button onclick="logout()">Cerrar sesion</button>
        <?php
        include_once '../../includes/scripts.php';
        ?>
        <script src="api/emprendedor.js"></script>
    </body>
</html>
