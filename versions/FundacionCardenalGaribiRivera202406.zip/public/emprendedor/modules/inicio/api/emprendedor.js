$(document).ready(function () {
    // Realiza una solicitud AJAX para obtener la información del perfil del emprendedor
    crearPeticion(
            'api/EmprendedorAPI.php',
            {case: "obtenerInfoPerfil"},
            function (response) {
                print(response);
                $('#info').text(JSON.stringify(response));
            }
    );
});
