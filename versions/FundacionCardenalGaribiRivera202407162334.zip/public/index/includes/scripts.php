<!-- Import Js Files -->
<script src="../../../assets/libs/jquery/jquery-3.7.1.min.js"></script>
<!-- Import Js Files -->
<script src="../../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../../assets/libs/simplebar/dist/simplebar.min.js"></script>
<script src="../../../assets/js/theme/theme.js"></script>
<script src="../../../assets/js/theme/feather.min.js"></script>

<!-- solar icons -->
<script src="../../../assets/libs/iconify/iconify-icon.min.js"></script>
<script src="../../../assets/libs/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="../../../assets/js/util.js"></script>