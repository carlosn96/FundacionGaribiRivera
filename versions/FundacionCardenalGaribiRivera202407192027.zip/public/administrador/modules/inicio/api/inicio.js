function ready() {
    // Realiza una solicitud AJAX para obtener la información del perfil del emprendedor
    
}

