<?php

include_once '../loader.php';

class RevisorSesion extends API {

    public function cerrarSesion() {
        Sesion::cerrar();
        $this->enviarRespuesta(["sesionActiva" => Sesion::esActiva()]);
    }

    public function verificarSesion() {
        $info = Sesion::info();
        $esLocalhost = in_array($_SERVER['SERVER_NAME'], ['127.0.0.1', 'localhost']) ||
                filter_var($_SERVER['SERVER_NAME'], FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
        $projectFolder = $esLocalhost ? '/' . explode('/', trim($_SERVER["PHP_SELF"], '/'))[0] : '';
        $rootUrl = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"] . $projectFolder;
        $this->enviarRespuesta([
            "sesionActiva" => Sesion::esActiva(),
            "url" => $info["url"] ?? null,
            "usuario" => $info["usuario"],
            "root" => $rootUrl/* ,
                  "server" => $_SERVER */
        ]);
    }

}

Util::iniciarAPI("RevisorSesion");
