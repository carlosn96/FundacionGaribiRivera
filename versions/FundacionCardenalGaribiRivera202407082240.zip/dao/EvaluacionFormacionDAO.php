<?php

class EvaluacionFormacionDAO extends DAO {

    public function guardar(EvaluacionFormacion $evaluacion) {
        
    }

}
