
<script src="../../../assets/js/vendor.min.js"></script>
<!-- Import Js Files -->
<script src="../../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../../assets/libs/simplebar/dist/simplebar.min.js"></script>
<script src="../../../assets/js/theme/app.dark.init.js"></script>
<script src="../../../assets/js/theme/theme.js"></script>
<script src="../../../assets/js/theme/app.min.js"></script>
<script src="../../../assets/js/theme/sidebarmenu.js"></script>
<script src="../../../assets/js/theme/feather.min.js"></script>
<script src="../../../assets/libs/jquery/jquery-3.7.1.min.js"></script>

<script src="../../../assets/js/iconify-icon.min.js"></script>
<script src="../../../assets/libs/jquery-steps/build/jquery.steps.min.js"></script>
<script src="../../../assets/libs/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="../../../assets/libs/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="../../../assets/js/util.js"></script>
<script src="../../../assets/js/form-wizard.js"></script>
