<div class="card">
    <div class="card-body wizard-content">
        <h4 class="card-title">Evaluacion de la formación</h4>
        <p class="card-subtitle mb-3"> Para ser respondido una vez que se concluyó la formación </p>
        <form id="evaluacionForm" class="validation-wizard wizard-circle needs-validation" >
            <h6>Beneficios de la formación</h6>
            <section>
                <div class="mb-3">
                    <label class="form-label">¿Consideras que hubo algún beneficio a nivel personal después de la formación o acompañamiento?</label>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="huboBeneficioPersonal" id="beneficioSi" value="1" required>
                                <label class="form-check-label" for="beneficioSi">Sí</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="huboBeneficioPersonal" id="beneficioNo" value="0" checked required>
                                <label class="form-check-label" for="beneficioNo">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="beneficiosObtenidos" class="form-label">¿Cuáles fueron los beneficios obtenidos?</label>
                    <textarea class="form-control" id="beneficiosObtenidos" name="beneficiosObtenidos" rows="2" disabled required></textarea>
                </div>
            </section>
            <h6>Administración del negocio</h6>
            <section>
                <div class="mb-3">
                    <label for="ventasMensuales" class="form-label">¿Cuál es el monto mensual de tus ventas?</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="ventasMensuales" name="ventasMensuales" min="0" value="0" required>
                        <span class="input-group-text">.00</span>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="gastosMensuales" class="form-label">¿Cuál es el monto mensual de tus gastos/egresos?</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="gastosMensuales" name="gastosMensuales" min="0" value="0" required>
                        <span class="input-group-text">.00</span>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="utilidadesMensuales" class="form-label">¿Cuál es el monto de tus utilidades mensuales?</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="utilidadesMensuales" name="utilidadesMensuales" min="0" value="0" required>
                        <span class="input-group-text">.00</span>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="sueldoMensual" class="form-label">¿Cuál es tu sueldo mensual?</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="sueldoMensual" name="sueldoMensual" min="0" value="0" required>
                        <span class="input-group-text">.00</span>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">¿Es tu negocio la principal fuente de ingresos para ti, a nivel personal?</label>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="esIngresoPrincipalPersonal" id="ingresoPrincipalSi" value="1" required>
                                <label class="form-check-label" for="ingresoPrincipalSi">Sí</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="esIngresoPrincipalPersonal" id="ingresoPrincipalNo" value="0" required>
                                <label class="form-check-label" for="ingresoPrincipalNo">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">¿Es tu negocio la principal fuente de ingresos para tu familia?</label>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="esIngresoPrincipalFamiliar" id="esIngresoPrincipalFamiliarSi" value="1" required>
                                <label class="form-check-label" for="esIngresoPrincipalFamiliarSi">Sí</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="esIngresoPrincipalFamiliar" id="esIngresoPrincipalFamiliarNo" value="0" required>
                                <label class="form-check-label" for="esIngresoPrincipalFamiliarNo">No</label>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <h6>Gestión y optimización del ahorro</h6>
            <section>
                <div class="mb-3">
                    <label class="form-label">¿Tienes el hábito de ahorrar de manera constante y a largo plazo?</label>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="tieneHabitoAhorro" id="habitoAhorroSi" value="1" required>
                                <label class="form-check-label" for="habitoAhorroSi">Sí</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="tieneHabitoAhorro" id="habitoAhorroNo" value="0" required>
                                <label class="form-check-label" for="habitoAhorroNo">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">¿Cuentas con algún sistema de ahorro?</label>
                    <div class="row">
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="cuentaConSistemaAhorro" id="sistemaAhorroSi" value="1" required>
                                <label class="form-check-label" for="sistemaAhorroSi">Sí</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="cuentaConSistemaAhorro" id="sistemaAhorroNo" value="0" required checked>
                                <label class="form-check-label" for="sistemaAhorroNo">No</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="detallesSistemaAhorro" class="form-label">¿Con qué sistema de ahorro cuentas?</label>
                    <input type="text" class="form-control" id="detallesSistemaAhorro" name="detallesSistemaAhorro" disabled required>
                </div>
                <div class="mb-3">
                    <label for="objetivoAhorro" class="form-label">¿Cuál es el objetivo principal de tus ahorros?</label>
                    <select class="form-select" id="objetivoAhorro" name="objetivoAhorro" disabled required>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="ahorroMensual" class="form-label">¿Cuál es el monto aproximado de tus ahorros mensuales?</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" class="form-control" id="ahorroMensual" name="ahorroMensual" min="0" value="0" disabled required>
                        <span class="input-group-text">.00</span>
                    </div>
                </div>
            </section>
        </form>
    </div>
</div>