const urlAPI = "api/EvaluacionFormacionAPI.php";
function ready() {
    $('input[name="huboBeneficioPersonal"]').change(function () {
        $('#beneficiosObtenidos').prop('disabled', !($(this).val() === '1'));
    });

    $('input[name="cuentaConSistemaAhorro"]').change(function () {
        var isEnabled = $(this).val() === '1';
        $('#detallesSistemaAhorro, #objetivoAhorro, #ahorroMensual').prop('disabled', !isEnabled);
    });
    recuperarInfoFormulario();
}

function enviarForm() {
    crearPeticion(urlAPI, {
        case: "guardarEvaluacion",
        data: $("#evaluacionForm").serialize()
    }, print, printError);
}


function recuperarInfoFormulario() {
    crearPeticion(urlAPI, {case: "recuperarInfoFormulario"}, (res) => {
        $.each(res, (group, opciones) => {
            crearSelector($("#"+group), opciones);
        });
    });
}
