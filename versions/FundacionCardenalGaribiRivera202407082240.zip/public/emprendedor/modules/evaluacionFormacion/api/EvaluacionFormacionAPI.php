<?php

include_once '../../../../../loader.php';

class EvaluacionFormacionAPI extends API {

    function guardarEvaluacion() {
        $this->enviarResultadoOperacion(getAdminEvaluacionFormacion()->guardar($this->data));
    }

    function recuperarInfoFormulario() {
        $admin = getAdminEvaluacionFormacion();
        $this->enviarRespuesta([
            "objetivoAhorro" => $admin->recuperarObjetivosAhorro()
        ]);
    }

}

Util::iniciarAPI(EvaluacionFormacionAPI::class);
