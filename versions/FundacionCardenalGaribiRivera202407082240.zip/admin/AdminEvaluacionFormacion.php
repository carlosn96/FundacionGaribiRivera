<?php

class AdminEvaluacionFormacion extends Admin {

    
    public function __construct() {
        parent::__construct(new EvaluacionFormacionDAO());
    }
    
    public function recuperarObjetivosAhorro() {
        return $this->extraerInfoCampoEspecifico("evaluacion_formacion_objetivo_ahorros",
                        "id_objetivo", "descripcion");
    }
    
    public function guardar($data) {
        return $this->dao->guardar($this->construirEvaluacionFormacion($data));
    }

    private function construirEvaluacionFormacion($data) {
        $huboBeneficioPersonal = $data['huboBeneficioPersonal'] === '1';
        $beneficiosObtenidos = $data['beneficiosObtenidos'] ?? "";
        $ventasMensuales = (float) $data['ventasMensuales'];
        $gastosMensuales = (float) $data['gastosMensuales'];
        $utilidadesMensuales = (float) $data['utilidadesMensuales'];
        $sueldoMensual = (float) $data['sueldoMensual'];
        $ingresoPrincipalPersonal = (float) $data['esIngresoPrincipalPersonal'] === '1';
        $ingresoPrincipalFamiliar = (float) $data['esIngresoPrincipalFamiliar'] === '1';
        $tieneHabitoAhorro = $data['tieneHabitoAhorro'] === '1';
        $cuentaConSistemaAhorro = $data['cuentaConSistemaAhorro'] === '1';
        $detallesSistemaAhorro = $data['detallesSistemaAhorro'] ?? "";
        $objetivoAhorro = $data['objetivoAhorro'] ?? "";
        $ahorroMensual = (float) $data['ahorroMensual'] ?? 0;
        return new EvaluacionFormacion($huboBeneficioPersonal, $beneficiosObtenidos,
                $ventasMensuales, $gastosMensuales, $utilidadesMensuales, $sueldoMensual,
                $ingresoPrincipalPersonal, $ingresoPrincipalFamiliar, $tieneHabitoAhorro,
                $cuentaConSistemaAhorro, $detallesSistemaAhorro, $objetivoAhorro, $ahorroMensual
        );
    }

}
