<?php

class AdminFactory {

    private static $instances = [];

    public static function getAdminEvaluacionFormacion(): AdminEvaluacionFormacion {
        return self::getOrCreateInstance(AdminEvaluacionFormacion::class);
    }

    public static function getAdminLineaBase(): AdminLineaBase {
        return self::getOrCreateInstance(AdminLineaBase::class);
    }

    public static function getAdminMailer(): AdminMailer {
        return self::getOrCreateInstance(AdminMailer::class);
    }

    private static function getOrCreateInstance(string $class): Admin {
        if (!isset(self::$instances[$class])) {
            self::$instances[$class] = new $class();
        }
        return self::$instances[$class];
    }
}