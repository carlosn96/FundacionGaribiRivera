<div class="card">
    <div class="card-body">
        <h4 class="card-title">Linea Base</h4>
        <p class="mb-3 card-subtitle">Información proporcionada</p>
        <div>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex active" data-bs-toggle="tab" href="#preliminar" role="tab" aria-selected="true">
                        <span>
                            <i class="ti ti-home-2 fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Preliminar</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#identificacion" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-user fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Identificación</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#domicilio" role="tab" aria-selected="false">
                        <span>
                            <i class="ri-map-pin-2-line"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Domicilio</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#socioeconomico" role="tab" aria-selected="false">
                        <span>
                            <i class="ti ti-wallet fs-4"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Socioeconómico</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#negocio" role="tab" aria-selected="false">
                        <span>
                            <i class="ri-store-line"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Negocio</span>
                    </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link d-flex" data-bs-toggle="tab" href="#analisisNegocio" role="tab" aria-selected="false">
                        <span>
                            <i class="ri-search-line"></i>
                        </span>
                        <span class="d-none d-md-block ms-2">Análisis de Negocio</span>
                    </a>
                </li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active show p-3" id="preliminar" role="tabpanel">
                    <h3>Preliminar</h3>
                    <p>Otro Medio Conoce Fundación: <span id="preliminar-otroMedioConoceFundacion"></span></p>
                    <p>Otra Razón Recurre Fundación: <span id="preliminar-otraRazonRecurreFundacion"></span></p>
                    <p>Razón Recurre Fundación: <span id="preliminar-razonRecurreFundacion-descripcion"></span></p>
                    <p>Solicita Crédito: <span id="preliminar-solicitaCredito-descripcion"></span></p>
                    <p>Utiliza Crédito: <span id="preliminar-utilizaCredito"></span></p>
                    <p>Tiempo Dedica Capacitación: <span id="preliminar-tiempoDedicaCapacitacion-descripcion"></span></p>
                </div>
                <div class="tab-pane p-3" id="identificacion" role="tabpanel">
                    <h3>Identificación</h3>
                    <p>Género: <span id="identificacion-genero"></span></p>
                    <p>Edad: <span id="identificacion-edad"></span></p>
                    <p>Estado Civil: <span id="identificacion-estadoCivil-descripcion"></span></p>
                    <p>Escolaridad: <span id="identificacion-escolaridad-descripcion"></span></p>
                    <p>Discapacidad: <span id="identificacion-discapacidad"></span></p>
                </div>
                <div class="tab-pane p-3" id="domicilio" role="tabpanel">
                    <h3>Domicilio</h3>
                    <p>Calle: <span id="domicilio-calle"></span></p>
                    <p>Calle Cruce 1: <span id="domicilio-calleCruce1"></span></p>
                    <p>Calle Cruce 2: <span id="domicilio-calleCruce2"></span></p>
                    <p>Número Exterior: <span id="domicilio-numeroExterior"></span></p>
                    <p>Número Interior: <span id="domicilio-numeroInterior"></span></p>
                    <p>Código Postal: <span id="domicilio-codigoPostal-codigo"></span></p>
                    <p>Colonia: <span id="domicilio-codigoPostal-colonia"></span></p>
                    <p>Municipio: <span id="domicilio-municipio-nombre"></span></p>
                    <p>Estado: <span id="domicilio-estado"></span></p>
                    <p>Comunidad Parroquial: <span id="domicilio-comunidadParroquial-nombre"></span></p>
                    <p>Decanato: <span id="domicilio-comunidadParroquial-decanato"></span></p>
                    <p>Vicaria: <span id="domicilio-comunidadParroquial-vicaria"></span></p>
                </div>
                <div class="tab-pane p-3" id="socioeconomico" role="tabpanel">
                    <h3>Socioeconómico</h3>
                    <p>Cantidad Dependientes: <span id="socioeconomico-cantidadDependientes"></span></p>
                    <p>Ocupación Actual: <span id="socioeconomico-ocupacionActual-descripcion"></span></p>
                    <p>Ingreso Mensual: <span id="socioeconomico-ingresoMensual-descripcion"></span></p>
                </div>
                <div class="tab-pane p-3" id="negocio" role="tabpanel">
                    <h3>Negocio</h3>
                    <p>Nombre: <span id="negocio-nombre"></span></p>
                    <p>Teléfono: <span id="negocio-telefono"></span></p>
                    <p>Calle: <span id="negocio-calle"></span></p>
                    <p>Calle Cruce 1: <span id="negocio-calleCruce1"></span></p>
                    <p>Calle Cruce 2: <span id="negocio-calleCruce2"></span></p>
                    <p>Número Exterior: <span id="negocio-numExterior"></span></p>
                    <p>Número Interior: <span id="negocio-numInterior"></span></p>
                    <p>Código Postal: <span id="negocio-codigoPostal-codigo"></span></p>
                    <p>Colonia: <span id="negocio-codigoPostal-colonia"></span></p>
                    <p>Antigüedad: <span id="negocio-antiguedad"></span></p>
                    <p>Cantidad de Empleados: <span id="negocio-cantEmpleados"></span></p>
                    <p>Giro: <span id="negocio-giro-descripcion"></span></p>
                    <p>Otro Giro: <span id="negocio-otroGiro"></span></p>
                    <p>Actividad Principal: <span id="negocio-actividadPrincipal"></span></p>
                </div>
                <div class="tab-pane p-3" id="analisisNegocio" role="tabpanel">
                    <h3>Análisis de Negocio</h3>
                    <p>Problemas del Negocio: <span id="analisisNegocio-problemasNegocio"></span></p>
                    <p>Registra Entrada y Salida: <span id="analisisNegocio-registraEntradaSalida"></span></p>
                    <p>Asigna Sueldo: <span id="analisisNegocio-asignaSueldo"></span></p>
                    <p>Conoce Utilidades: <span id="analisisNegocio-conoceUtilidades"></span></p>
                    <p>Identifica Competencia: <span id="analisisNegocio-identificaCompetencia"></span></p>
                    <p>Quién es la Competencia: <span id="analisisNegocio-quienCompetencia"></span></p>
                    <p>Clientes del Negocio: <span id="analisisNegocio-clientesNegocio"></span></p>
                    <p>Ventajas del Negocio: <span id="analisisNegocio-ventajasNegocio"></span></p>
                    <p>Conoce Productos de Mayor Utilidad: <span id="analisisNegocio-conoceProductosMayorUtilidad"></span></p>
                    <p>Porcentaje de Ganancias: <span id="analisisNegocio-porcentajeGanancias"></span></p>
                    <p>Ahorro: <span id="analisisNegocio-ahorro"></span></p>
                    <p>Cuánto Ahorro: <span id="analisisNegocio-cuantoAhorro"></span></p>
                    <p>Razones No Ahorro: <span id="analisisNegocio-razonesNoAhorro"></span></p>
                    <p>Conoce Punto de Equilibrio: <span id="analisisNegocio-conocePuntoEquilibrio"></span></p>
                    <p>Separa Gastos: <span id="analisisNegocio-separaGastos"></span></p>
                    <p>Elabora Presupuesto: <span id="analisisNegocio-elaboraPresupuesto"></span></p>
                </div>
            </div>
        </div>
    </div>
</div>
