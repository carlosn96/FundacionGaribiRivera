<?php

header("location: inicio");