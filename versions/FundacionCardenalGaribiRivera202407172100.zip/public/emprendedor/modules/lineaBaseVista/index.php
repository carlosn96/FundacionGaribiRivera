<?php

echo "<pre>";
var_dump(json_decode($_GET["lb"]));

echo "</pre>";
