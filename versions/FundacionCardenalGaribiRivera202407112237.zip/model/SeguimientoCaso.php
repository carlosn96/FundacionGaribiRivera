<?php


class SeguimientoCaso {
    use Entidad;
    
    
}
