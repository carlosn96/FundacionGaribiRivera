<?php

include_once '../../../../../loader.php';

class SeguimientoCasoNuevoAPI extends API {

    function listarTiposEtapasFormacion() {
        $this->enviarRespuesta(getAdminEtapaFormacion()->listarTiposEtapasFormacion());
    }

    function guardarCaso() {
        $this->enviarRespuesta(["idCaso" => getAdminEmprendedor()->guardarSeguimientoCaso($this->data)]);
    }

    function guardarfotografiasCaso() {
        $fotos = [];
        foreach ($_FILES["fotografiasCaso"]['tmp_name'] as $file) {
            $fotos[] = file_get_contents($file);
        }
        $this->enviarResultadoOperacion(getAdminEmprendedor()->guardarFotografiasSeguimientoCaso($fotos, $this->data["idCaso"]));
    }

}

Util::iniciarAPI(SeguimientoCasoNuevoAPI::class);
