const urlAPI = "api/SeguimientoCasoNuevoAPI.php";
function ready() {
    $(document).ready(() => {
        let res = extraerParametrosURL(window.location).emprendedor;
        if (res) {
            let emprendedor = JSON.parse(res);
            recuperarCamposFormulario(emprendedor);
            ajustarDropzone();
            guardarSeguimientoCaso();
        } else {
            redireccionar("../seguimientoCaso/");
        }
    });
}

function recuperarCamposFormulario(emprendedor) {
    crearPeticion(urlAPI, {case: "listarTiposEtapasFormacion"}, (res) => {
        print(res);
        crearSelectorMultiple($("#etapasFormacionCursadas"), "etapasFormacionCursadas", res);
    });
    $("#tituloCard").append(emprendedor[2] + " " + emprendedor[3]);
}

function ajustarDropzone() {
    Dropzone.autoDiscover = false;
    const myDropzone = Dropzone.forElement("#fotografiasCasoForm");
    myDropzone.options.addRemoveLinks = true;
    myDropzone.options.dictRemoveFile = "Eliminar archivo";
    myDropzone.options.acceptedFiles = ".png, .jpg, .jpeg";
}

function guardarSeguimientoCaso() {
    $("#guardarSeguimientoCasoBtn").click(() => {
        crearPeticion(urlAPI, {case: "guardarCaso", data: $("#nuevoCasoForm").serialize()}, (res) => {
            if (res.idCaso) {
                const formData = new FormData();
                const dropzoneFiles = Dropzone.forElement("#fotografiasCasoForm").getAcceptedFiles();
                dropzoneFiles.forEach((file, index) => {
                    formData.append(`fotografiasCaso[${index}]`, file, file.name);
                });
                formData.append("case", "guardarfotografiasCaso");
                formData.append("data", "idCaso=" + res.idCaso);
                crearPeticion(urlAPI, formData, (res) => {
                    print(res);
                });
            }
        });
    });
}