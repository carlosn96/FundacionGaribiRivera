<!-- Required meta tags -->
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<!-- Favicon icon-->
<link rel="shortcut icon" type="image/png" href="../../../assets/images/logos/ico.png" />
<link rel="stylesheet" href="../../../assets/libs/sweetalert2/dist/sweetalert2.min.css">
<!-- Core Css -->
<link rel="stylesheet" href="../../../assets/css/modules.css" />
<title>Fundación Cardenal Garibi Rivera</title>
<!-- jvectormap  -->
<link rel="stylesheet" href="../../../assets/libs/jvectormap/jquery-jvectormap.css">