<?php

class EmprendedorDAO extends DAO {

    private const NOMBRE_TABLA_EMPRENDEDOR = "usuario_emprendedor";
    private const VISTA_LISTADO_EMPRENDEDORES = "lista_emprendedores";
    private const INSERTAR_NUEVO = "INSERT INTO " . self::NOMBRE_TABLA_EMPRENDEDOR . " (id_usuario) VALUES(?)";
    private const INSERTAR_FOTOGRAFIAS_CASO = "INSERT INTO seguimiento_caso_lista_fotografias_caso VALUES (?,?)";

    /* public function insertar_nuevo(Emprendedor $emprendedor) {
      $args = new PreparedStatmentArgs();
      $args->add("i", $emprendedor->get_id_usuario());
      return $this->ejecutar_instruccion_preparada(self::INSERTAR_NUEVO, $args);
      } */

    public function guardarfotografiasSeguimientoCaso(array $fotos, $idCaso) {
        $prep = $this->prepararInstruccion(self::INSERTAR_FOTOGRAFIAS_CASO);
        $totalEx = 0;
        foreach ($fotos as $foto) {
            $prep->agregarInt($idCaso);
            $prep->agregarBlob($foto);
            $totalEx += $prep->ejecutar();
            $prep->clear();
        }
        return $totalEx === count($fotos);
    }

    public function guardarSeguimientoCaso($seguimiento) {
        //return ultimo id
        return 10; // o null
    }

}
