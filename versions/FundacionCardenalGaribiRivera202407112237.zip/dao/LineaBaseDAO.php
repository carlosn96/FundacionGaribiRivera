<?php

class LineaBaseDAO extends DAO {

    private const LISTAR_EMPRENDEDOR_LINEA_BASE = "SELECT * FROM listar_emprendedor_con_linea_base";

    public function listarEmprendedoresLineaBase() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_EMPRENDEDOR_LINEA_BASE);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }
}
