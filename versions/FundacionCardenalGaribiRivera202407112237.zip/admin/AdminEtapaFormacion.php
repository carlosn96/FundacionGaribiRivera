<?php

class AdminEtapaFormacion extends Admin {

    public function __construct() {
        parent::__construct(new EtapaFormacionDAO());
    }

    public function listarEtapasFormacion() {
        $etapas = [];
        foreach ($this->dao->listarEtapasFormacion() as $data) {
            $etapas[] = $this->construirEtapa($data)->toArray();
        }
        return $etapas;
    }
    
    public function listarTiposEtapasFormacion() {
        return $this->dao->listarTiposEtapasFormacion();
    }

    private function construirEtapa($data): EtapaFormacion {
        return new EtapaFormacion($data["idEmprendedor"] ?? 0,
                $data["nombre"], $data["fechaInicio"],
                $data["fechaFin"], isset($data["descripcionTipo"]) ?
                Util::map($data["tipo"], $data["descripcionTipo"]) : $data["tipo"]);
    }
}
