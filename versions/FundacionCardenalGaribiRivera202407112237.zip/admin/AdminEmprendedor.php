<?php

class AdminEmprendedor extends Admin {

    public function __construct() {
        parent::__construct(new EmprendedorDAO());
    }

//    public function guardarSeguimientoCaso(SeguimientoCaso $seguimiento) {
//        return $this->dao->guardarSeguimientoCaso($seguimiento);
//    }
    
        public function guardarSeguimientoCaso($seguimiento) {
        return $this->dao->guardarSeguimientoCaso($seguimiento);
    }
    
    public function guardarfotografiasSeguimientoCaso(array $fotos, $idCaso) {
        return $this->dao->guardarfotografiasSeguimientoCaso($fotos, $idCaso);
    }

    private function construirSeguimientoCaso($data) {
        return new SeguimientoCaso( );
    }
}
