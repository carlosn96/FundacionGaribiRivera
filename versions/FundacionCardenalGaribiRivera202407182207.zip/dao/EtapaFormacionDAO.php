<?php

class EtapaFormacionDAO extends DAO {

    private const TABLA = "etapa_formacion";
    private const VISTA = "listar_etapas_formacion";
    private const LISTAR_ETAPAS_FORMACION = "SELECT * FROM " . self::VISTA;
    private const LISTAR_TIPOS_ETAPAS_FORMACION = "SELECT * FROM " . self::TABLA . "_tipo";
    private const OBTENER_ETAPA_ACTUAL = self::LISTAR_ETAPAS_FORMACION . " WHERE esActual = 1";

    public function listarEtapasFormacion() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_ETAPAS_FORMACION);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }
    
    public function obtenerEtapaActual() {
        $rs = $this->ejecutarInstruccion(self::OBTENER_ETAPA_ACTUAL);
        return $rs ? $rs->fetch_assoc() : [];
    }

    public function listarTiposEtapasFormacion() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_TIPOS_ETAPAS_FORMACION);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }
}
