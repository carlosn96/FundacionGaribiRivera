<?php

/**
 * Description of LineaBase
 *
 * @author JuanCarlos
 */
class LineaBase {

    use Entidad;

    private LineaBasePreliminar $preliminar;
    private int $id;
    private int $idEtapa;
    private int $idUsuario;

    public function __construct(int $idEtapa, int $idUsuario, LineaBasePreliminar $preliminar, $id = 0) {
        $this->preliminar = $preliminar;
        $this->id = $id;
        $this->idUsuario = $idUsuario;
        $this->idEtapa = $idEtapa;
    }

    public function getIdEtapa(): int {
        return $this->idEtapa;
    }

    public function getIdUsuario(): int {
        return $this->idUsuario;
    }

    public function setIdEtapa(int $idEtapa): void {
        $this->idEtapa = $idEtapa;
    }

    public function setIdUsuario(int $idUsuario): void {
        $this->idUsuario = $idUsuario;
    }

    public function getId(): int {
        return $this->id;
    }

    public function setId(int $id): void {
        $this->id = $id;
    }

    public function getPreliminar(): LineaBasePreliminar {
        return $this->preliminar;
    }

    public function setPreliminar(LineaBasePreliminar $preliminar): void {
        $this->preliminar = $preliminar;
    }

}
