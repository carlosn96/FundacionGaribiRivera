<?php

class AdminLineaBase extends Admin {

    public function __construct() {
        parent::__construct(new LineaBaseDAO());
    }

    public function guardarLineaBase($data) {
        var_dump($data);
        $preliminar = $this->construirSeccionPreliminar($data);
        return $this->dao->guardarLineaBase(new LineaBase($data["idEtapa"], $data["idUsuario"], $preliminar));
    }

    public function existeLineaBase($idUsuario): bool {
        return $this->dao->existeLineaBase($idUsuario);
    }

    public function construirSeccionPreliminar($data): LineaBasePreliminar {
        $medioConoceFundacion = $data["medioConocimiento"] ?? [];
        $otroMedioConoceFundacion = $data["otroMedioConocimiento"][1] ?? "";
        $razonRecurreFundacion = $data["razonRecurre"];
        $otraRazonRecurreFundacion = $data["otraRazonRecurre"] ?? "";
        $solicitaCredito = $data["solicitaCredito"] ?? "";
        $utilizaCredito = $data["utilizaCredito"] ?? "";
        $tiempoDedicaCapacitacion = $data["tiempoCapacitacion"];
        return new LineaBasePreliminar($medioConoceFundacion, $otroMedioConoceFundacion,
                $razonRecurreFundacion, $otraRazonRecurreFundacion, $solicitaCredito, $utilizaCredito,
                $tiempoDedicaCapacitacion);
    }

    public function recuperarListaMedioConocimientoFund() {
        return $this->extraerInfoCampoEspecifico("linea_base_medio_conocimiento", "id_medio", "descripcion");
    }

    public function recuperarListaEstrategiasIncrementarVentas() {
        return $this->extraerInfoCampoEspecifico("linea_base_estrategias_incrementar_ventas", "id_estrategia", "descripcion");
    }

    public function recuperarListaEmpleaGanancias() {
        return $this->extraerInfoCampoEspecifico("linea_base_empleo_ganancias", "id_empleo", "descripcion");
    }

    public function recuperarListaRazonRecurreFund() {
        return $this->extraerInfoCampoEspecifico("linea_base_razon_recurre", "id_razon", "descripcion");
    }

    public function recuperarListaSolicitaCredito() {
        return $this->extraerInfoCampoEspecifico("linea_base_solicita_credito", "id_solicitud", "descripcion");
    }

    public function recuperarListaUtilizaCredito() {
        return $this->extraerInfoCampoEspecifico("linea_base_utiliza_credito", "id_utilidad", "descripcion");
    }

    public function recuperarListaTiempoCapacitacion() {
        return $this->extraerInfoCampoEspecifico("linea_base_tiempo_capacitacion", "id_tiempo", "descripcion");
    }

    public function recuperarListaEscolaridad() {
        return $this->extraerInfoCampoEspecifico("linea_base_escolaridad", "id_escolaridad", "descripcion");
    }

    public function recuperarListaEstadoCivil() {
        return $this->extraerInfoCampoEspecifico("linea_base_estado_civil", "id_estado_civil", "descripcion");
    }

    public function recuperarListaVicarias() {
        return $this->extraerInfoCampoEspecifico("linea_base_arquidiocesis_vicaria", "id_vicaria", "nombre");
    }

    public function recuperarListaDecanato($vicaria) {
        return $this->extraerInfoCampoEspecifico("linea_base_arquidiocesis_decanato",
                        "id_decanato", "nombre", "WHERE id_vicaria = $vicaria");
    }

    public function recuperarListaComunidadParroquial($decanato) {
        return $this->extraerInfoCampoEspecifico("linea_base_arquidiocesis_comunidad_parroquial",
                        "id_comunidad", "nombre", "WHERE id_decanato = $decanato");
    }

    public function recuperarListaOcupaciones() {
        return $this->extraerInfoCampoEspecifico("linea_base_ocupacion",
                        "id_ocupacion", "descripcion");
    }

    public function recuperarListaRangosIngreso() {
        return $this->extraerInfoCampoEspecifico("linea_base_rango_ingreso_mensual",
                        "id_rango", "descripcion");
    }

    public function recuperarListaGiroNegocio() {
        return $this->extraerInfoCampoEspecifico("linea_base_giro_negocio",
                        "id_giro", "descripcion");
    }

    public function listarEmprendoresConLineaBase() {
        return $this->dao->listarEmprendedoresLineaBase();
    }

    public function buscarCodigoPostal($cp) {
        return $this->dao->buscarCodigoPostal($cp);
    }

}
