DELIMITER $$

CREATE PROCEDURE guardar_linea_base (
    IN p_id_usuario INT,
    IN p_id_etapa INT,
    IN p_fecha_creacion DATETIME,
    IN p_json_preliminar JSON
)
BEGIN
    DECLARE v_id_linea_base INT;
    DECLARE v_otro_medio_conocimiento VARCHAR(45);
    DECLARE v_otro_razon_recurre_fundacion VARCHAR(45);
    DECLARE v_id_razon_recurre_fundacion INT;
    DECLARE v_id_solicita_credito INT;
    DECLARE v_id_utiliza_credito INT;
    DECLARE v_id_tiempo_dedica_formacion INT;
    DECLARE v_medioConoceFundacion JSON;
    DECLARE v_medio JSON;
    DECLARE v_index INT DEFAULT 0;
    DECLARE v_medio_count INT;
    
    -- Insertar en la tabla linea_base
    INSERT INTO linea_base (id_usuario, id_etapa, fecha_creacion)
    VALUES (p_id_usuario, p_id_etapa, p_fecha_creacion);
    
    SET v_id_linea_base = LAST_INSERT_ID();

    -- Extraer datos del JSON
    SET v_otro_medio_conocimiento = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.otroMedioConoceFundacion'));
    SET v_otro_razon_recurre_fundacion = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.otraRazonRecurreFundacion'));
    SET v_id_razon_recurre_fundacion = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.razonRecurreFundacion'));
    SET v_id_solicita_credito = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.solicitaCredito'));
    SET v_id_utiliza_credito = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.utilizaCredito'));
    SET v_id_tiempo_dedica_formacion = JSON_UNQUOTE(JSON_EXTRACT(p_json_preliminar, '$.tiempoDedicaCapacitacion'));
    
    -- Insertar en la tabla linea_base_seccion_preliminar
    INSERT INTO linea_base_seccion_preliminar (
        id_linea_base, 
        otro_medio_conocimiento,
        otro_razon_recurre_fundacion,
        id_razon_recurre_fundacion,
        id_solicita_credito,
        id_utiliza_credito,
        id_tiempo_dedica_formacion
    ) VALUES (
        v_id_linea_base,
        v_otro_medio_conocimiento,
        v_otro_razon_recurre_fundacion,
        v_id_razon_recurre_fundacion,
        v_id_solicita_credito,
        v_id_utiliza_credito,
        v_id_tiempo_dedica_formacion
    );
    
    -- Insertar en la tabla linea_base_lista_medio_conocimiento
    SET v_medioConoceFundacion = JSON_EXTRACT(p_json_preliminar, '$.medioConoceFundacion');
    SET v_medio_count = JSON_LENGTH(v_medioConoceFundacion);
    
    WHILE v_index < v_medio_count DO
        SET v_medio = JSON_UNQUOTE(JSON_EXTRACT(v_medioConoceFundacion, CONCAT('$[', v_index, ']')));
        INSERT INTO linea_base_lista_medio_conocimiento (id_linea_base, id_medio)
        VALUES (v_id_linea_base, v_medio);
        SET v_index = v_index + 1;
    END WHILE;
END$$

DELIMITER ;
