<nav class="navbar navbar-expand-lg p-0">
    <ul class="navbar-nav">
        <li class="nav-item nav-icon-hover-bg rounded-circle">
            <a class="nav-link sidebartoggler" id="headerCollapse" href="javascript:void(0)">
                <iconify-icon icon="solar:list-bold-duotone" class="fs-7"></iconify-icon>
            </a>
        </li>
    </ul>

    <div class="d-block d-lg-none py-3">
        <img src="../../../assets/images/logos/logo-dark.svg" class="dark-logo img-fluid" alt="Logo-Dark" />
        <img src="../../../assets/images/logos/logo-light.svg" class="light-logo img-fluid" alt="Logo-light" />
    </div>

    <a class="navbar-toggler p-0 border-0" href="javascript:void(0)" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="p-2">
            <i class="ti ti-dots fs-7"></i>
        </span>
    </a>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <div class="d-flex align-items-center justify-content-between">
            <a href="javascript:void(0)" class="nav-link d-flex d-lg-none align-items-center justify-content-center" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobilenavbar" aria-controls="offcanvasWithBothOptions">
                <div class="nav-icon-hover-bg rounded-circle ">
                    <i class="ti ti-align-justified fs-7"></i>
                </div>
            </a>
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-center">
                <li class="nav-item nav-icon-hover-bg rounded-circle">
                    <a class="nav-link moon dark-layout" href="javascript:void(0)">
                        <iconify-icon icon="solar:moon-line-duotone" class="moon fs-6"></iconify-icon>
                    </a>
                    <a class="nav-link sun light-layout" href="javascript:void(0)">
                        <iconify-icon icon="solar:sun-2-line-duotone" class="sun fs-6"></iconify-icon>
                    </a>
                </li>
                <!-- ------------------------------- -->
                <!-- start Messages cart Dropdown -->
                <!-- ------------------------------- -->
                <li class="nav-item dropdown nav-icon-hover-bg rounded-circle">
                    <a class="nav-link position-relative" href="javascript:void(0)" id="drop3" aria-expanded="false">
                        <iconify-icon icon="solar:chat-dots-line-duotone" class="fs-6"></iconify-icon>
                        <div class="pulse">
                            <span class="heartbit border-warning"></span>
                            <span class="point text-bg-warning"></span>
                        </div>
                    </a>
                    <div class="dropdown-menu content-dd dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop3">
                        <!--  Messages -->
                        <div class="d-flex align-items-center py-3 px-7">
                            <h3 class="mb-0 fs-5">Messages</h3>
                            <span class="badge bg-info ms-3">5 new</span>
                        </div>

                        <div class="message-body" data-simplebar>
                            <a href="javascript:void(0)" class="dropdown-item px-7 d-flex align-items-center py-6">
                                <span class="flex-shrink-0">
                                    <img src="../../../assets/images/profile/user-2.jpg" alt="user" width="45" class="rounded-circle" />
                                </span>
                                <div class="w-100 ps-3">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h5 class="mb-0 fs-3 fw-normal">
                                            Roman Joined the Team!
                                        </h5>
                                        <span class="fs-2 text-nowrap d-block text-muted">9:08 AM</span>
                                    </div>
                                    <span class="fs-2 d-block mt-1 text-muted">Congratulate him</span>
                                </div>
                            </a>
                        </div>
                        <div class="py-6 px-7 mb-1">
                            <button class="btn btn-primary w-100">
                                See All Messages
                            </button>
                        </div>
                    </div>
                </li>
                <!-- ------------------------------- -->
                <!-- end Messages cart Dropdown -->
                <!-- ------------------------------- -->



                <!-- ------------------------------- -->
                <!-- start profile Dropdown -->
                <!-- ------------------------------- -->
                <li class="nav-item dropdown">
                    <a class="nav-link position-relative ms-6" href="javascript:void(0)" id="drop1" aria-expanded="false">
                        <div class="d-flex align-items-center flex-shrink-0">
                            <div class="user-profile me-sm-3 me-2">
                                <img src="../../../assets/images/profile/user-1.jpg" width="40" class="rounded-circle" alt="spike-img">
                            </div>
                            <span class="d-sm-none d-block"><iconify-icon icon="solar:alt-arrow-down-line-duotone"></iconify-icon></span>

                            <div class="d-none d-sm-block">
                                <h6 class="fs-4 mb-1 profile-name">

                                </h6>
                                <p class="fs-3 lh-base mb-0 profile-subtext">

                                </p>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-menu content-dd dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop1">
                        <div class="profile-dropdown position-relative" data-simplebar>
                            <div class="d-flex align-items-center justify-content-between pt-3 px-7">
                                <h3 class="mb-0 fs-5">User Profile</h3>

                            </div>

                            <div class="d-flex align-items-center mx-7 py-9 border-bottom">
                                <img src="../../../assets/images/profile/user-1.jpg" alt="user" width="90" class="rounded-circle" />
                                <div class="ms-4">
                                    <h4 class="mb-0 fs-5 fw-normal profile-name-full"></h4>
                                    <span class="text-muted profile-subtext"></span>
                                    <p class="text-muted mb-0 mt-1 d-flex align-items-center profile-emailD">
                                    <iconify-icon icon="solar:mailbox-line-duotone" class="fs-4 me-1"></iconify-icon>
                                    </p>
                                </div>
                            </div>

                            <div class="message-body">
                                <a href="https://bootstrapdemos.wrappixel.com/spike/dist/main/page-user-profile.html" class="dropdown-item px-7 d-flex align-items-center py-6">
                                    <span class="btn px-3 py-2 bg-info-subtle rounded-1 text-info shadow-none">
                                        <iconify-icon icon="solar:wallet-2-line-duotone" class="fs-7"></iconify-icon>
                                    </span>
                                    <div class="w-100 ps-3 ms-1">
                                        <h5 class="mb-0 mt-1 fs-4 fw-normal">
                                            My Profile
                                        </h5>
                                        <span class="fs-3 d-block mt-1 text-muted">Account Settings</span>
                                    </div>
                                </a>

                                <a href="https://bootstrapdemos.wrappixel.com/spike/dist/main/app-email.html" class="dropdown-item px-7 d-flex align-items-center py-6">
                                    <span class="btn px-3 py-2 bg-success-subtle rounded-1 text-success shadow-none">
                                        <iconify-icon icon="solar:shield-minimalistic-line-duotone" class="fs-7"></iconify-icon>
                                    </span>
                                    <div class="w-100 ps-3 ms-1">
                                        <h5 class="mb-0 mt-1 fs-4 fw-normal">My Inbox</h5>
                                        <span class="fs-3 d-block mt-1 text-muted">Messages & Emails</span>
                                    </div>
                                </a>

                                <a href="https://bootstrapdemos.wrappixel.com/spike/dist/main/app-notes.html" class="dropdown-item px-7 d-flex align-items-center py-6">
                                    <span class="btn px-3 py-2 bg-danger-subtle rounded-1 text-danger shadow-none">
                                        <iconify-icon icon="solar:card-2-line-duotone" class="fs-7"></iconify-icon>
                                    </span>
                                    <div class="w-100 ps-3 ms-1">
                                        <h5 class="mb-0 mt-1 fs-4 fw-normal">My Task</h5>
                                        <span class="fs-3 d-block mt-1 text-muted">To-do and Daily
                                            Tasks</span>
                                    </div>
                                </a>
                            </div>

                            <div class="py-6 px-7 mb-1">
                                <a href="javascript:cerrarSesion()" class="btn btn-outline-success w-100">Cerrar sesión</a>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- ------------------------------- -->
                <!-- end profile Dropdown -->
                <!-- ------------------------------- -->
            </ul>
        </div>
    </div>
</nav>