<?php

include_once '../loader.php';

class RevisorSesion extends API {

    public function cerrarSesion() {
        Sesion::cerrar();
        $this->enviarRespuesta(["sesionCerrada" => is_null(Sesion::obtenerUsuarioActual())]);
    }

    public function verificarSesion() {
        $info = Sesion::info();
        $host = $_SERVER["SERVER_NAME"];

        if ($host === 'localhost') {
            $rootPath = "/FundacionCardenalGaribiRivera202405"; //Nombre de la carpeta donde esta guardada dentro del directorio de htdocs de Apache
        } else {
            $rootPath =  "/public/index/modules/inicio/";
        }

        $this->enviarRespuesta([
            "sesionActiva" => Sesion::esActiva(),
            "url" => $info["url"] ?? null,
            "token" => $info["token"],
            "root" => $_SERVER["REQUEST_SCHEME"] . "://" . $host . $rootPath // Asegúrate de que esta ruta apunte al inicio de sesión
        ]);
    }

}

Util::iniciarAPI("RevisorSesion");
/*
 * 
 * 


 */