<?php

class InstruccionPreparada {

    private const TIPOS_DATOS_PERMITIDOS = ["s", "i", "d", "b"];
    private const TIPO_DATO_INDEX = 0;
    private const DATO_INDEX = 1;

    private array $datos;
    private array $blob;
    private mysqli_stmt $instruccionPreparada;

    function __construct(mysqli_stmt $instruccion) {
        $this->instruccionPreparada = $instruccion;
        $this->datos = array();
        $this->blob = array();
    }

    function agregarString($valor) {
        $this->agregarParametro("s", $valor);
    }

    function agregarInt($valor) {
        $this->agregarParametro("i", $valor);
    }

    function agregarDouble($valor) {
        $this->agregarParametro("d", $valor);
    }

    function agregarBlob(int $numeroArgumento, $datos) {
        $this->blob["numeroArgumento"] = $numeroArgumento;
        $this->blob["datos"] = $datos;
    }

    private function agregarParametro($tipo, $valor) {
        if (!in_array($tipo, self::TIPOS_DATOS_PERMITIDOS)) {
            throw new Exception("Tipo de dato no permitido");
        }
        array_push($this->datos, [$tipo, $valor]);
    }

    private function compilar() {
        $parametros = "";
        $datos = [];
        foreach ($this->datos as $valor) {
            $parametros .= $valor[self::TIPO_DATO_INDEX];
            array_push($datos, $valor[self::DATO_INDEX]);
        }
        $this->instruccionPreparada->bind_param($parametros, ...$datos);
        if (count($this->blob) > 0) {
            $this->instruccionPreparada->send_long_data($this->blob["numeroArgumento"], $this->blob["datos"]);
        }
    }

    function ejecutar(): bool {
        $this->compilar();
        return $this->instruccionPreparada->execute();
    }

    /**
     * Obtener una fila de resultados como un array asociativo
     * <p>Devuelve un array asociativo que corresponde a la fila obtenida o <b><code>Array vacío</code></b> si no hay más filas.</p><p><b>Nota</b>: Los nombres de campo devueltos por esta función son <i>sensible a mayúsculas y minúsculas</i>.</p><p><b>Nota</b>: Esta función establece los campos NULL al valor <b><code>NULL</code></b> de PHP.</p>
     * @return array <p>Devuelve un array asociativo de strings que representa la fila obtenida en el conjunto de resultados, donde cada clave en el array representa el nombre de una de las columnas del conjunto de resultados o <b><code>NULL</code></b> si no hay más filas en el conjunto de resultados.</p><p>Si dos o más columnas del resultado tienen los mismos nombres de campo, la última columna tendrá precedencia. Para acceder a la(s) otra(s) columna(s) con el mismo nombre, debe acceder al resultado con índices numéricos mediante el uso de <code>mysqli_fetch_row()</code> o agregar alias a los nombres.</p>
     * @link http://php.net/manual/es/mysqli-result.fetch-assoc.php
     * @see mysqli_fetch_array(), mysqli_fetch_row(), mysqli_fetch_object(), mysqli_query(), mysqli_data_seek()
     */
    public function ejecutarConsulta($fetchAll = false): array {
        $this->compilar();
        if ($this->instruccionPreparada->execute()) {
            if (($resultado = $this->instruccionPreparada->get_result()) !== false) {
                return $fetchAll ? $resultado->fetch_all(MYSQLI_ASSOC) ?? [] :
                        $resultado->fetch_assoc() ?? [];
            }
        }
        return [];
    }

    /**
     * Obtiene todas las filas de resultados como un array asociativo, un array numérico o ambos
     * <p><b>mysqli_fetch_all()</b> obtiene todas las filas de resultados y devuelve el conjunto de resultados como un array asociativo, un array numérico o ambos.</p>
     * @param int $resulttype <p>Este parámetro opcional es una constante que indica qué tipo de array debe producirse a partir de los datos de la fila actual. Los valores posibles para este parámetro son las constantes <b><code>MYSQLI_ASSOC</code></b>, <b><code>MYSQLI_NUM</code></b> o <b><code>MYSQLI_BOTH</code></b>.</p>
     * @return mixed <p>Devuelve un array de arrays asociativos que contienen las filas de resultados.</p>
     * @link http://php.net/manual/es/mysqli-result.fetch-all.php
     * @see mysqli_fetch_array(), mysqli_query()
     */
    public function ejecutarConsultaMultiple(): array {
        return $this->ejecutarConsulta(true);
    }

}
