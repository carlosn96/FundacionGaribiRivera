<script src="../../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../../assets/libs/simplebar/dist/simplebar.min.js"></script>
<script src="../../../assets/js/theme/app.dark.init.js"></script>
<script src="../../../assets/js/theme/theme.js"></script>
<script src="../../../assets/js/theme/sidebarmenu.js"></script>
<script src="../../../assets/js/theme/feather.min.js"></script>
<!-- solar icons -->
<script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
<script src="../../../assets/js/util.js"></script>
