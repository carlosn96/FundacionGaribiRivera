
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
        include_once '../../includes/head.php';
        ?>
    </head>
    <body>
        <h1>Perfil del Emprendedor</h1>
        <div id="info"></div>
        <!-- Import Js Files -->
        <button class="btn btn-primary btn-lg btn-block" onclick="logout()">Cerrar sesion</button>
        <button type="button" class="btn btn-primary btn-lg btn-block">Block level button</button>
        <button type="button" class="btn btn-secondary btn-lg btn-block">Block level button</button>
        <?php
        include_once '../../includes/scripts.php';
        ?>
        <script src="api/emprendedor.js"></script>
    </body>
</html>
