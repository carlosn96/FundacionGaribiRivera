<div class="preloader" id="preloader">
    <img src="../../../assets/images/logos/loader.svg" alt="loader" class="lds-ripple img-fluid" />
</div>