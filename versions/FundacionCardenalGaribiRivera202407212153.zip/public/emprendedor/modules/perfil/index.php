<?php

include_once '../../includes/emprendedorTemplate.php';

renderizarPlantillaEmprendedor(__DIR__, ["api/perfil.js"]);
