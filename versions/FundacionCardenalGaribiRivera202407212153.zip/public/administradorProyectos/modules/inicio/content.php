
<div class="card">
    <div class="card-body">
        <div class="d-flex mb-4 justify-content-between align-items-center">
            <h4 class="card-title mb-0">Emprendedores</h4>
            <div class="dropdown">
                <button id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" class="rounded-circle btn-transparent rounded-circle btn-sm px-1 btn shadow-none">
                    <i class="ti ti-dots-vertical fs-7 d-block"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton1">
                    <li>
                        <a class="dropdown-item" href="javascript:void(0)">-</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="table-responsive" data-simplebar="init" id="container">
            
        </div>
    </div>
</div>