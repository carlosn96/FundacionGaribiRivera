<?php

include_once '../../includes/administradorTemplate.php';

renderizarPlantillaEmprendedor(__DIR__, ["api/perfil.js"]);
