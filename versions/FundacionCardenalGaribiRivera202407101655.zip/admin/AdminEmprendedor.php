<?php

class AdminEmprendedor extends Admin {

    public function __construct() {
        parent::__construct(new EmprendedorDAO());
    }


}
