<div class="card">
    <div class="card-body wizard-content">
        <h4 class="card-title">Segumiento de caso</h4>
        <p class="card-subtitle mb-3"> Listado de emprendedores con linea base completa</p>

        <div id="tablaEmprendedores">
        </div>

    </div>
</div>