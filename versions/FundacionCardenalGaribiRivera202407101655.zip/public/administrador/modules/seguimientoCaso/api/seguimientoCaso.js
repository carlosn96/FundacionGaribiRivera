const urlAPI = "api/SeguimientoCasoAPI.php";
function ready() {
    crearPeticion(urlAPI, {case: "recuperarEmprendedores"}, function (res) {
        var dataTabla = [];
        $.each(res, (i, emprendedor) => {
            const btnsMenuPlantel = [
                {"url": "javascript:void(0)", "titulo": "<i class='ti ti-edit'></i> Editar"},
                {"url": "javascript:void(0)", "titulo": "<i class='ti ti-trash'></i>Eliminar"}
            ];
            dataTabla.push({
                "Etapa": {celda: emprendedor.etapa},
                "Nombre": {celda: emprendedor.nombre},
                "Apellidos": {celda: emprendedor.apellidos},
                "Correo electrónico": {celda: emprendedor.correo},
                "Acciones": {isHTML: true, celda: crearBotonMenuDesplegable("Acciones", btnsMenuPlantel, "success")}
            });
        });
        construirTabla(dataTabla, "table-bordered border-success", "tablaEmprendedores");
        crearDataTable("#tablaEmprendedores");
    });
}