<?php

header("Location: modules/inicio");