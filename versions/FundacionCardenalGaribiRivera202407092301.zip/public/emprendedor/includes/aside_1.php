<aside class="left-sidebar with-vertical">

    <div class="scroll-sidebar" data-simplebar>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav" class="mb-0">

                <!-- ============================= -->
                <!-- Home -->
                <!-- ============================= -->
                <li class="nav-small-cap">
                <iconify-icon icon="solar:menu-dots-bold-duotone" class="nav-small-cap-icon fs-5"></iconify-icon>
                <span class="hide-menu">Home</span>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link sidebar-link primary-hover-bg" href="" id="get-url" aria-expanded="false">
                        <span class="aside-icon p-2 bg-primary-subtle rounded-1">
                            <iconify-icon icon="solar:screencast-2-line-duotone" class="fs-6"></iconify-icon>
                        </span>
                        <span class="hide-menu ps-1">Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class="sidebar-link sidebar-link success-hover-bg" href="../main/index2.html" aria-expanded="false">
                        <span class="aside-icon p-2 bg-success-subtle rounded-1">
                            <iconify-icon icon="solar:chart-line-duotone" class="fs-6"></iconify-icon>
                        </span>
                        <span class="hide-menu ps-1">Dashboard 2</span>
                    </a>
                </li>

                <!-- =================== -->
                <!-- Classes -->
                <!-- =================== -->
                <li class="sidebar-item">
                    <a class="sidebar-link sidebar-link indigo-hover-bg" href="../main/classes.html" aria-expanded="false">
                        <span class="aside-icon p-2 bg-indigo-subtle rounded-1">
                            <iconify-icon icon="solar:planet-3-line-duotone" class="fs-6"></iconify-icon>
                        </span>
                        <span class="hide-menu ps-1">Classes</span>
                    </a>
                </li>

                <!-- ============================= -->
                <!-- Tables -->
                <!-- ============================= -->
                <li class="nav-small-cap">
                <iconify-icon icon="solar:menu-dots-bold-duotone" class="nav-small-cap-icon fs-5"></iconify-icon>
                <span class="hide-menu">Tables</span>
                </li>

                <!-- =================== -->
                <!-- Bootstrap Table -->
                <!-- =================== -->
                <li class="sidebar-item">
                    <a class="sidebar-link has-arrow indigo-hover-bg" href="javascript:void(0)" aria-expanded="false">
                        <span class="aside-icon p-2 bg-indigo-subtle rounded-1">
                            <iconify-icon icon="solar:sidebar-minimalistic-line-duotone" class="fs-6"></iconify-icon>
                        </span>
                        <span class="hide-menu ps-1">Bootstrap Table</span>
                    </a>
                    <ul aria-expanded="false" class="collapse first-level">
                        <li class="sidebar-item">
                            <a href="../main/table-basic.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Basic Table</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="../main/table-dark-basic.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Dark Basic Table</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="../main/table-sizing.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Sizing Table</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="../main/table-layout-coloured.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Coloured Table</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- =================== -->
                <!-- Datatable -->
                <!-- =================== -->
                <li class="sidebar-item">
                    <a class="sidebar-link has-arrow info-hover-bg" href="javascript:void(0)" aria-expanded="false">
                        <span class="aside-icon p-2 bg-info-subtle rounded-1">
                            <iconify-icon icon="solar:tablet-line-duotone" class="fs-6"></iconify-icon>
                        </span>
                        <span class="hide-menu ps-1">Datatables</span>
                    </a>
                    <ul aria-expanded="false" class="collapse first-level">
                        <li class="sidebar-item">
                            <a href="../main/table-datatable-basic.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Basic Initialisation</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="../main/table-datatable-api.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">API</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a href="../main/table-datatable-advanced.html" class="sidebar-link">
                                <span class="sidebar-icon"></span>
                                <span class="hide-menu">Advanced Initialisation</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>

    <!-- ---------------------------------- -->
    <!-- Start Vertical Layout Sidebar -->
    <!-- ---------------------------------- -->
</aside>



Mi arquitectura es
INICIO
Novedades
../inicio/
FORMACION
Evaluación de la formacion
../evaluacionFormacion/
Talleres de capacitacion
../misTalleres/
DOCUMENTACION
Ficha de Inscripción
../fichaInscripcion/
