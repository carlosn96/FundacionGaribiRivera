<?php

include_once '../../includes/template.php';

renderizarCotenido(__DIR__, [
    'api/vistaEvaluacionFormacion.js'
]);
