<?php

header("Location: public/");
