<?php

class LineaBaseDAO extends DAO {
    
}
