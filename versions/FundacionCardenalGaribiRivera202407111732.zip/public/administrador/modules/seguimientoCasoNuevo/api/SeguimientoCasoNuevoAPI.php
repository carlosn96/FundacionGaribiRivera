<?php

include_once '../../../../../loader.php';

class SeguimientoCasoNuevoAPI extends API {

    function listarTiposEtapasFormacion() {
        $this->enviarRespuesta(getAdminEtapaFormacion()->listarTiposEtapasFormacion());
    }

    function guardarCaso() {
        var_dump($this->data);
        $this->enviarResultadoOperacion(getAdminEmprendedor()->guardarSeguimientoCaso($this->data));
    }
}

Util::iniciarAPI(SeguimientoCasoNuevoAPI::class);
