const urlAPI = "api/SeguimientoCasoNuevoAPI.php";
function ready() {
    let res = extraerParametrosURL(window.location).emprendedor;
    if (res) {
        let emprendedor = JSON.parse(res);
        recuperarCamposFormulario(emprendedor);
        ajustarDropzone();
        guardarSeguimientoCaso();
    } else {
        redireccionar("../seguimientoCaso/");
    }
}

function recuperarCamposFormulario(emprendedor) {
    crearPeticion(urlAPI, {case: "listarTiposEtapasFormacion"}, (res) => {
        print(res);
        crearSelectorMultiple($("#etapasFormacionCursadas"), "etapasFormacionCursadas", res);
    });
    $("#tituloCard").append(emprendedor[2] + " " + emprendedor[3]);
}

function ajustarDropzone() {
    Dropzone.autoDiscover = false;
    const myDropzone = Dropzone.forElement("#fotografiasCasoForm");
    myDropzone.options.addRemoveLinks = true;
    myDropzone.options.dictRemoveFile = "Eliminar archivo";
    myDropzone.options.acceptedFiles = ".png, .jpg, .jpeg";
}

function guardarSeguimientoCaso() {
    $("#guardarSeguimientoCasoBtn").click(() => {
        let data = $("#nuevoCasoForm").serialize();
        
        const form1 = $('#nuevoCasoForm')[0];
        const form2 = $('#fotografiasCasoForm')[0];
        const formData = new FormData(form1);

        // Añadir archivos del segundo formulario al FormData
        const files = $('#fotografiasCaso')[0].files;
        for (let i = 0; i < files.length; i++) {
            formData.append('fotografiasCaso[]', files[i]);
        }

        crearPeticion(urlAPI, {case: "guardarCaso", data: formData}, print);
    });
}