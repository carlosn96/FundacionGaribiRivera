const urlAPI = "api/SeguimientoCasoAPI.php";
function ready() {
    crearPeticion(urlAPI, {case: "recuperarEmprendedores"}, function (res) {
        var dataTabla = [];
        $.each(res, (i, emprendedor) => {
            dataTabla.push({
                "No.": emprendedor.idLineaBase,
                "Etapa": emprendedor.etapa,
                "Nombre": emprendedor.nombre,
                "Apellidos": emprendedor.apellidos,
                "Correo electrónico": emprendedor.correo
            });
        });
        var $tabla = construirTabla(dataTabla, "table-striped table-bordered display text-nowrap", "tablaEmprendedoresContenedor", "tablaEmprendedores");
        $("#tablaEmprendedores tbody").on("click", "tr", function () {
            var data = $tabla.row(this).data();
            print(data);
            $("#tituloModalEmprendedor").text(data[2] + " " + data[3]);
            var contenido = '';
            contenido += '<h5 class="card-title">' + data[1] + '</h5>';
            contenido += '<p class="card-text"><strong>Nombre:</strong> ' + data[2] + ' ' + data[3] + '</p>';
            contenido += '<p class="card-text"><strong>Email:</strong> ' + data[4] + '</p>';
            $('#cardModalEmprendedorContent').html(contenido);
            $("#btnDarSeguimiento").attr("href", "../seguimientoCasoNuevo/?emprendedor=" + JSON.stringify(data));
            $("#modalEmprendedor").modal('show');
        });
    });
}