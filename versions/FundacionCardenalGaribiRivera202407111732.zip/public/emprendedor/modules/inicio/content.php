<!-- 3. kichen sink -->
<div class="d-flex border-bottom title-part-padding px-0 mb-3 align-items-center">
            <div>
              <h4 class="mb-0 fs-5">Nuevos talleres de capacitación</h4>
            </div>
            <div class="ms-auto flex-shrink-0">
              
              <!-- Code Modal -->
              <div id="view-code3-modal" class="modal fade" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                  <div class="modal-content">
                    <div class="modal-header border-bottom">
                      <h5 class="modal-title" id="exampleModalLabel">
                        Kichen Sink - View Code
                      </h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <pre class="language-html">
<code>
&lt;div class=&quot;row justify-content-center&quot;&gt;
&lt;div class=&quot;col-lg-4 col-md-6&quot;&gt;
&lt;div class=&quot;card&quot;&gt;
  &lt;img src=&quot;./assets/images/blog/blog-img5.jpg&quot; class=&quot;card-img-top&quot; alt=&quot;...&quot; /&gt;
  &lt;div class=&quot;card-body p-10&quot;&gt;
    &lt;h5 class=&quot;card-title fs-5&quot;&gt;Nancy Henry&lt;/h5&gt;
    &lt;p class=&quot;card-text&quot;&gt;
      Some quick example text to build on the card title and make up the bulk of the card's content.
    &lt;/p&gt;
  &lt;/div&gt;
  &lt;ul class=&quot;list-group list-group-flush&quot;&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Cras justo odio&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Dapibus ac facilisis in&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Vestibulum at eros&lt;/li&gt;
  &lt;/ul&gt;
  &lt;div class=&quot;card-body button-group d-flex align-items-stretch p-10&quot;&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-heart fs-6 me-1&quot;&gt;&lt;/i&gt; Like&lt;/a&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-message-circle fs-6 me-1&quot;&gt;&lt;/i&gt; Comment&lt;/a&gt;
    &lt;div class=&quot;ms-auto&quot;&gt;
      &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center flex-column flex-sm-row&quot;&gt;&lt;i class=&quot;ti ti-share fs-6&quot;&gt;&lt;/i&gt; &lt;/a&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class=&quot;col-lg-4 col-md-6&quot;&gt;
&lt;div class=&quot;card&quot;&gt;
  &lt;img src=&quot;./assets/images/blog/blog-img6.jpg&quot; class=&quot;card-img-top&quot; alt=&quot;...&quot; /&gt;
  &lt;div class=&quot;card-body p-10&quot;&gt;
    &lt;h5 class=&quot;card-title fs-5&quot;&gt;George Jane&lt;/h5&gt;
    &lt;p class=&quot;card-text&quot;&gt;
      Some quick example text to build on the card title and make up the bulk of the card's content.
    &lt;/p&gt;
  &lt;/div&gt;
  &lt;ul class=&quot;list-group list-group-flush&quot;&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Cras justo odio&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Dapibus ac facilisis in&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Vestibulum at eros&lt;/li&gt;
  &lt;/ul&gt;
  &lt;div class=&quot;card-body button-group d-flex align-items-stretch p-10&quot;&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-heart fs-6 me-1&quot;&gt;&lt;/i&gt; Like&lt;/a&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-message-circle fs-6 me-1&quot;&gt;&lt;/i&gt; Comment&lt;/a&gt;
    &lt;div class=&quot;ms-auto&quot;&gt;
      &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center flex-column flex-sm-row&quot;&gt;&lt;i class=&quot;ti ti-share fs-6&quot;&gt;&lt;/i&gt; &lt;/a&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;div class=&quot;col-lg-4 col-md-6&quot;&gt;
&lt;div class=&quot;card&quot;&gt;
  &lt;img src=&quot;./assets/images/blog/blog-img8.jpg&quot; class=&quot;card-img-top&quot; alt=&quot;...&quot; /&gt;
  &lt;div class=&quot;card-body p-10&quot;&gt;
    &lt;h5 class=&quot;card-title fs-5&quot;&gt;Samuel Eliza&lt;/h5&gt;
    &lt;p class=&quot;card-text&quot;&gt;
      Some quick example text to build on the card title and make up the bulk of the card's content.
    &lt;/p&gt;
  &lt;/div&gt;
  &lt;ul class=&quot;list-group list-group-flush&quot;&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Cras justo odio&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Dapibus ac facilisis in&lt;/li&gt;
    &lt;li class=&quot;list-group-item&quot;&gt;Vestibulum at eros&lt;/li&gt;
  &lt;/ul&gt;
  &lt;div class=&quot;card-body button-group d-flex align-items-stretch p-10&quot;&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-heart fs-6 me-1&quot;&gt;&lt;/i&gt; Like&lt;/a&gt;
    &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center&quot;&gt;&lt;i class=&quot;ti ti-message-circle fs-6 me-1&quot;&gt;&lt;/i&gt; Comment&lt;/a&gt;
    &lt;div class=&quot;ms-auto&quot;&gt;
      &lt;a href=&quot;#&quot; class=&quot;btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center flex-column flex-sm-row&quot;&gt;&lt;i class=&quot;ti ti-share fs-6&quot;&gt;&lt;/i&gt; &lt;/a&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
</code>
</pre>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
            </div>
          </div>
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6">
              <div class="card">
                <img src="https://scontent.fgdl2-2.fna.fbcdn.net/v/t39.30808-6/448505248_486741770364728_5783864345166702188_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=127cfc&_nc_ohc=40p6NnbN59wQ7kNvgGxa-om&_nc_ht=scontent.fgdl2-2.fna&oh=00_AYDnDx5ucC4V7IpFR0NH-UHlapWZW6bbF6I1JN2_qfnXhg&oe=66878CDD" class="card-img-top" alt="..." />
                <div class="card-body p-10">
                  <h5 class="card-title fs-5">Taller Planeación Financiera</h5>
                  <p class="card-text">
                   La planeación financiera implica crear un plan detallado y personalizado para lograr objetivos financieros con costos y recursos definidos.
                  </p>
                </div>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">impartido por: Héctor Quezada</li>
                
                </ul>
                <div class="card-body button-group d-flex align-items-stretch p-10">
                  <a href="#" class="btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center"><i
                      class="ti ti-heart fs-6 me-1"></i> Entrar</a>
                  
                 
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="card">
                <img src="https://scontent.fgdl2-1.fna.fbcdn.net/v/t39.30808-6/448485471_486745317031040_5819898417526514816_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=127cfc&_nc_ohc=WGkzGFBpJIMQ7kNvgHNYkZe&_nc_ht=scontent.fgdl2-1.fna&oh=00_AYADA2I9gPQRyjT-zsxUuvlSkG9vnQQwMWB8-2cX9Hf5Og&oe=66879D5F" class="card-img-top" alt="..." />
                <div class="card-body p-10">
                  <h5 class="card-title fs-5">Taller Desarrollo Personal</h5>
                  <p class="card-text">
Esté taller tiene la finalidad de encauzar a los emprendedores en el autoconocimiento, solidaridad y motivación personal.                  </p>
                </div>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">impartido por: Claudia Macossay</li>
                
                </ul>
                <div class="card-body button-group d-flex align-items-stretch p-10">
                  <a href="#" class="btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center"><i
                      class="ti ti-heart fs-6 me-1"></i> Entrar</a>
                
                  
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-6">
              <div class="card">
                <img src="https://scontent.fgdl2-1.fna.fbcdn.net/v/t39.30808-6/448691829_486193907086181_8553816350221684140_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=127cfc&_nc_ohc=g-yEUDEaKXMQ7kNvgFW0QcQ&_nc_ht=scontent.fgdl2-1.fna&oh=00_AYCUA5vpp--mzmY_TVO7bRGCL7w81lQTPWpQfQfvU8aqBA&oe=6687B1C1" class="card-img-top" alt="..." />
                <div class="card-body p-10">
                  <h5 class="card-title fs-5">Taller de Mercadotecnia</h5>
                  <p class="card-text">
                    La Mercadotecnia es el proceso para satisfacer necesidades de consumo mediante la generación, oferta e intercambio de productos de valor.
                  </p>
                </div>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">impartido por: Benjamín Valdéz</li>
                
                </ul>
                <div class="card-body button-group d-flex align-items-stretch p-10" >
                  <a href="#" class="btn bg-secondary-subtle text-secondary px-2 d-flex align-items-center"><i
                      class="ti ti-heart fs-6 me-1"></i> Entrar</a>
                  
                 
                </div>
              </div>
            </div>
          </div>
          <!-- 3. end kichen sink -->