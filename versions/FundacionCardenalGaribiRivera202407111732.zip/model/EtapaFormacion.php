<?php

class EtapaFormacion {

    use Entidad;

    private $idEntidad;
    private $nombre;
    private $fechaInicio;
    private $fechaFin;
    private $tipo;

    public function __construct($idEntidad, $nombre, $fechaInicio, $fechaFin, $tipo) {
        $this->idEntidad = $idEntidad;
        $this->nombre = $nombre;
        $this->fechaInicio = $fechaInicio;
        $this->fechaFin = $fechaFin;
        $this->tipo = $tipo;
    }

    public function getIdEntidad() {
        return $this->idEntidad;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getFechaInicio() {
        return $this->fechaInicio;
    }

    public function getFechaFin() {
        return $this->fechaFin;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function setIdEntidad($idEntidad): void {
        $this->idEntidad = $idEntidad;
    }

    public function setNombre($nombre): void {
        $this->nombre = $nombre;
    }

    public function setFechaInicio($fechaInicio): void {
        $this->fechaInicio = $fechaInicio;
    }

    public function setFechaFin($fechaFin): void {
        $this->fechaFin = $fechaFin;
    }

    public function setTipo($tipo): void {
        $this->tipo = $tipo;
    }
}
