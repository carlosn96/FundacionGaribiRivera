<?php
class Fichainscripcion_emprendedor {
   
    private $nombre_completo;
    private $genero;
    private $fecha_nacimiento;
    private $edad;
    private $correo_electronico;
    private $telefono;
    private $calle_numero;
    private $colonia;
    private $cp;
    private $municipio;
    private $estado;
    private $parroquia;
    private $escolaridad;
    private $discapacidad;
    private $e_civil;
    private $ingreso_mensual;
    private $ocupacion;
    private $calle_numero_negocio;
    private $colonia_negocio;
    private $codigo_postal;
    private $municipio_negocio;
    private $estado_negocio;
    private $telefono_negocio;
    private $antiguedad_negocio;
    private $num_empleados;
    private $giro_negocio;
    private $otro_giro;
    private $principal_actividad;
    private $otra_actividad;
    private $tiene_competencia;
    private $tiene_sueldo_negocio;
    private $conoce_utilidad_negocio;
    private $competencia_input;
    private $ingresos_personales;
    private $ingresos_familiares;
    private $estrategias_ventas;
    private $otras_estrategias;
    private $productos_utilidad;
    private $utilidades_negocio;
    private $punto_equilibrio;
    private $gastos_separados;
    private $presupuesto_negocio;
    private $clientes_negocio;
    private $ventajas_negocio;
    private $lleva_Registros ;
    private $ventas_Mensuales ;
    private $gastos_Mensuales ;
    private $utilidades_Mensuales ;
    private $sueldo_Mensual;
    private $ahorroPermanente ;
    private $sistemaAhorro ;
    private $objetivoAhorro ;
    private $montoAhorroMensual;
    private $ahorroNegocio;
    
    public function __construct($nombre_completo, $genero, $fecha_nacimiento, $edad, $correo_electronico, $telefono, $calle_numero, $colonia, $cp, $municipio, $estado, $parroquia, $escolaridad, $discapacidad, $e_civil, $ingreso_mensual, $ocupacion, $calle_numero_negocio, $colonia_negocio, $codigo_postal, $municipio_negocio, $estado_negocio, $telefono_negocio, $antiguedad_negocio, $num_empleados, $giro_negocio, $otro_giro, $principal_actividad, $otra_actividad, $tiene_competencia, $tiene_sueldo_negocio, $conoce_utilidad_negocio, $competencia_input, $ingresos_personales, $ingresos_familiares, $estrategias_ventas, $otras_estrategias, $productos_utilidad, $utilidades_negocio, $punto_equilibrio, $gastos_separados, $presupuesto_negocio, $clientes_negocio, $ventajas_negocio, $lleva_Registros, $ventas_Mensuales, $gastos_Mensuales, $utilidades_Mensuales, $sueldo_Mensual, $ahorroPermanente, $sistemaAhorro, $objetivoAhorro, $montoAhorroMensual, $ahorroNegocio) {
        $this->nombre_completo = $nombre_completo;
        $this->genero = $genero;
        $this->fecha_nacimiento = $fecha_nacimiento;
        $this->edad = $edad;
        $this->correo_electronico = $correo_electronico;
        $this->telefono = $telefono;
        $this->calle_numero = $calle_numero;
        $this->colonia = $colonia;
        $this->cp = $cp;
        $this->municipio = $municipio;
        $this->estado = $estado;
        $this->parroquia = $parroquia;
        $this->escolaridad = $escolaridad;
        $this->discapacidad = $discapacidad;
        $this->e_civil = $e_civil;
        $this->ingreso_mensual = $ingreso_mensual;
        $this->ocupacion = $ocupacion;
        $this->calle_numero_negocio = $calle_numero_negocio;
        $this->colonia_negocio = $colonia_negocio;
        $this->codigo_postal = $codigo_postal;
        $this->municipio_negocio = $municipio_negocio;
        $this->estado_negocio = $estado_negocio;
        $this->telefono_negocio = $telefono_negocio;
        $this->antiguedad_negocio = $antiguedad_negocio;
        $this->num_empleados = $num_empleados;
        $this->giro_negocio = $giro_negocio;
        $this->otro_giro = $otro_giro;
        $this->principal_actividad = $principal_actividad;
        $this->otra_actividad = $otra_actividad;
        $this->tiene_competencia = $tiene_competencia;
        $this->tiene_sueldo_negocio = $tiene_sueldo_negocio;
        $this->conoce_utilidad_negocio = $conoce_utilidad_negocio;
        $this->competencia_input = $competencia_input;
        $this->ingresos_personales = $ingresos_personales;
        $this->ingresos_familiares = $ingresos_familiares;
        $this->estrategias_ventas = $estrategias_ventas;
        $this->otras_estrategias = $otras_estrategias;
        $this->productos_utilidad = $productos_utilidad;
        $this->utilidades_negocio = $utilidades_negocio;
        $this->punto_equilibrio = $punto_equilibrio;
        $this->gastos_separados = $gastos_separados;
        $this->presupuesto_negocio = $presupuesto_negocio;
        $this->clientes_negocio = $clientes_negocio;
        $this->ventajas_negocio = $ventajas_negocio;
        $this->lleva_Registros = $lleva_Registros;
        $this->ventas_Mensuales = $ventas_Mensuales;
        $this->gastos_Mensuales = $gastos_Mensuales;
        $this->utilidades_Mensuales = $utilidades_Mensuales;
        $this->sueldo_Mensual = $sueldo_Mensual;
        $this->ahorroPermanente = $ahorroPermanente;
        $this->sistemaAhorro = $sistemaAhorro;
        $this->objetivoAhorro = $objetivoAhorro;
        $this->montoAhorroMensual = $montoAhorroMensual;
        $this->ahorroNegocio = $ahorroNegocio;
        
        
    }
    
    public function get_nombre_completo() {
        return $this->nombre_completo;
    }

    public function get_genero() {
        return $this->genero;
    }

    public function get_fecha_nacimiento() {
        return $this->fecha_nacimiento;
    }

    public function get_edad() {
        return $this->edad;
    }

    public function get_correo_electronico() {
        return $this->correo_electronico;
    }

    public function get_telefono() {
        return $this->telefono;
    }

    public function get_calle_numero() {
        return $this->calle_numero;
    }

    public function get_colonia() {
        return $this->colonia;
    }

    public function get_cp() {
        return $this->cp;
    }

    public function get_municipio() {
        return $this->municipio;
    }

    public function get_estado() {
        return $this->estado;
    }

    public function get_parroquia() {
        return $this->parroquia;
    }

    public function get_escolaridad() {
        return $this->escolaridad;
    }

    public function get_discapacidad() {
        return $this->discapacidad;
    }

    public function get_e_civil() {
        return $this->e_civil;
    }

    public function get_ingreso_mensual() {
        return $this->ingreso_mensual;
    }

    public function get_ocupacion() {
        return $this->ocupacion;
    }

    public function get_calle_numero_negocio() {
        return $this->calle_numero_negocio;
    }

    public function get_colonia_negocio() {
        return $this->colonia_negocio;
    }

    public function get_codigo_postal() {
        return $this->codigo_postal;
    }

    public function get_municipio_negocio() {
        return $this->municipio_negocio;
    }

    public function get_estado_negocio() {
        return $this->estado_negocio;
    }

    public function get_telefono_negocio() {
        return $this->telefono_negocio;
    }

    public function get_antiguedad_negocio() {
        return $this->antiguedad_negocio;
    }

    public function get_num_empleados() {
        return $this->num_empleados;
    }

    public function get_giro_negocio() {
        return $this->giro_negocio;
    }

    public function get_otro_giro() {
        return $this->otro_giro;
    }

    public function get_principal_actividad() {
        return $this->principal_actividad;
    }

    public function get_otra_actividad() {
        return $this->otra_actividad;
    }

    public function get_tiene_competencia() {
        return $this->tiene_competencia;
    }

    public function get_tiene_sueldo_negocio() {
        return $this->tiene_sueldo_negocio;
    }

    public function get_conoce_utilidad_negocio() {
        return $this->conoce_utilidad_negocio;
    }

    public function get_competencia_input() {
        return $this->competencia_input;
    }

    public function get_ingresos_personales() {
        return $this->ingresos_personales;
    }

    public function get_ingresos_familiares() {
        return $this->ingresos_familiares;
    }

    public function get_estrategias_ventas() {
        return $this->estrategias_ventas;
    }

    public function get_otras_estrategias() {
        return $this->otras_estrategias;
    }

    public function get_productos_utilidad() {
        return $this->productos_utilidad;
    }

    public function get_utilidades_negocio() {
        return $this->utilidades_negocio;
    }

    public function get_punto_equilibrio() {
        return $this->punto_equilibrio;
    }

    public function get_gastos_separados() {
        return $this->gastos_separados;
    }

    public function get_presupuesto_negocio() {
        return $this->presupuesto_negocio;
    }

    public function get_clientes_negocio() {
        return $this->clientes_negocio;
    }

    public function get_ventajas_negocio() {
        return $this->ventajas_negocio;
    }

    public function get_lleva_Registros() {
        return $this->lleva_Registros;
    }

    public function get_ventas_Mensuales() {
        return $this->ventas_Mensuales;
    }

    public function get_gastos_Mensuales() {
        return $this->gastos_Mensuales;
    }

    public function get_utilidades_Mensuales() {
        return $this->utilidades_Mensuales;
    }

    public function get_sueldo_Mensual() {
        return $this->sueldo_Mensual;
    }

    public function get_ahorroPermanente() {
        return $this->ahorroPermanente;
    }

    public function get_sistemaAhorro() {
        return $this->sistemaAhorro;
    }

    public function get_objetivoAhorro() {
        return $this->objetivoAhorro;
    }

    public function get_montoAhorroMensual() {
        return $this->montoAhorroMensual;
    }

    public function get_ahorroNegocio() {
        return $this->ahorroNegocio;
    }

    public function set_nombre_completo($nombre_completo): void {
        $this->nombre_completo = $nombre_completo;
    }

    public function set_genero($genero): void {
        $this->genero = $genero;
    }

    public function set_fecha_nacimiento($fecha_nacimiento): void {
        $this->fecha_nacimiento = $fecha_nacimiento;
    }

    public function set_edad($edad): void {
        $this->edad = $edad;
    }

    public function set_correo_electronico($correo_electronico): void {
        $this->correo_electronico = $correo_electronico;
    }

    public function set_telefono($telefono): void {
        $this->telefono = $telefono;
    }

    public function set_calle_numero($calle_numero): void {
        $this->calle_numero = $calle_numero;
    }

    public function set_colonia($colonia): void {
        $this->colonia = $colonia;
    }

    public function set_cp($cp): void {
        $this->cp = $cp;
    }

    public function set_municipio($municipio): void {
        $this->municipio = $municipio;
    }

    public function set_estado($estado): void {
        $this->estado = $estado;
    }

    public function set_parroquia($parroquia): void {
        $this->parroquia = $parroquia;
    }

    public function set_escolaridad($escolaridad): void {
        $this->escolaridad = $escolaridad;
    }

    public function set_discapacidad($discapacidad): void {
        $this->discapacidad = $discapacidad;
    }

    public function set_e_civil($e_civil): void {
        $this->e_civil = $e_civil;
    }

    public function set_ingreso_mensual($ingreso_mensual): void {
        $this->ingreso_mensual = $ingreso_mensual;
    }

    public function set_ocupacion($ocupacion): void {
        $this->ocupacion = $ocupacion;
    }

    public function set_calle_numero_negocio($calle_numero_negocio): void {
        $this->calle_numero_negocio = $calle_numero_negocio;
    }

    public function set_colonia_negocio($colonia_negocio): void {
        $this->colonia_negocio = $colonia_negocio;
    }

    public function set_codigo_postal($codigo_postal): void {
        $this->codigo_postal = $codigo_postal;
    }

    public function set_municipio_negocio($municipio_negocio): void {
        $this->municipio_negocio = $municipio_negocio;
    }

    public function set_estado_negocio($estado_negocio): void {
        $this->estado_negocio = $estado_negocio;
    }

    public function set_telefono_negocio($telefono_negocio): void {
        $this->telefono_negocio = $telefono_negocio;
    }

    public function set_antiguedad_negocio($antiguedad_negocio): void {
        $this->antiguedad_negocio = $antiguedad_negocio;
    }

    public function set_num_empleados($num_empleados): void {
        $this->num_empleados = $num_empleados;
    }

    public function set_giro_negocio($giro_negocio): void {
        $this->giro_negocio = $giro_negocio;
    }

    public function set_otro_giro($otro_giro): void {
        $this->otro_giro = $otro_giro;
    }

    public function set_principal_actividad($principal_actividad): void {
        $this->principal_actividad = $principal_actividad;
    }

    public function set_otra_actividad($otra_actividad): void {
        $this->otra_actividad = $otra_actividad;
    }

    public function set_tiene_competencia($tiene_competencia): void {
        $this->tiene_competencia = $tiene_competencia;
    }

    public function set_tiene_sueldo_negocio($tiene_sueldo_negocio): void {
        $this->tiene_sueldo_negocio = $tiene_sueldo_negocio;
    }

    public function set_conoce_utilidad_negocio($conoce_utilidad_negocio): void {
        $this->conoce_utilidad_negocio = $conoce_utilidad_negocio;
    }

    public function set_competencia_input($competencia_input): void {
        $this->competencia_input = $competencia_input;
    }

    public function set_ingresos_personales($ingresos_personales): void {
        $this->ingresos_personales = $ingresos_personales;
    }

    public function set_ingresos_familiares($ingresos_familiares): void {
        $this->ingresos_familiares = $ingresos_familiares;
    }

    public function set_estrategias_ventas($estrategias_ventas): void {
        $this->estrategias_ventas = $estrategias_ventas;
    }

    public function set_otras_estrategias($otras_estrategias): void {
        $this->otras_estrategias = $otras_estrategias;
    }

    public function set_productos_utilidad($productos_utilidad): void {
        $this->productos_utilidad = $productos_utilidad;
    }

    public function set_utilidades_negocio($utilidades_negocio): void {
        $this->utilidades_negocio = $utilidades_negocio;
    }

    public function set_punto_equilibrio($punto_equilibrio): void {
        $this->punto_equilibrio = $punto_equilibrio;
    }

    public function set_gastos_separados($gastos_separados): void {
        $this->gastos_separados = $gastos_separados;
    }

    public function set_presupuesto_negocio($presupuesto_negocio): void {
        $this->presupuesto_negocio = $presupuesto_negocio;
    }

    public function set_clientes_negocio($clientes_negocio): void {
        $this->clientes_negocio = $clientes_negocio;
    }

    public function set_ventajas_negocio($ventajas_negocio): void {
        $this->ventajas_negocio = $ventajas_negocio;
    }

    public function set_lleva_Registros($lleva_Registros): void {
        $this->lleva_Registros = $lleva_Registros;
    }

    public function set_ventas_Mensuales($ventas_Mensuales): void {
        $this->ventas_Mensuales = $ventas_Mensuales;
    }

    public function set_gastos_Mensuales($gastos_Mensuales): void {
        $this->gastos_Mensuales = $gastos_Mensuales;
    }

    public function set_utilidades_Mensuales($utilidades_Mensuales): void {
        $this->utilidades_Mensuales = $utilidades_Mensuales;
    }

    public function set_sueldo_Mensual($sueldo_Mensual): void {
        $this->sueldo_Mensual = $sueldo_Mensual;
    }

    public function set_ahorroPermanente($ahorroPermanente): void {
        $this->ahorroPermanente = $ahorroPermanente;
    }

    public function set_sistemaAhorro($sistemaAhorro): void {
        $this->sistemaAhorro = $sistemaAhorro;
    }

    public function set_objetivoAhorro($objetivoAhorro): void {
        $this->objetivoAhorro = $objetivoAhorro;
    }

    public function set_montoAhorroMensual($montoAhorroMensual): void {
        $this->montoAhorroMensual = $montoAhorroMensual;
    }

    public function set_ahorroNegocio($ahorroNegocio): void {
        $this->ahorroNegocio = $ahorroNegocio;
    }

    
        function toArray() {
        return get_object_vars($this);
    }
}
