<?php

class EtapaFormacionDAO extends DAO {

    private const TABLA = "etapa_formacion";
    private const VISTA = "listar_etapas_formacion";
    private const LISTAR_ETAPAS_FORMACION = "SELECT * FROM " . self::VISTA;
    private const LISTAR_TIPOS_ETAPAS_FORMACION = "SELECT * FROM " . self::TABLA . "_tipo";

    public function listarEtapasFormacion() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_ETAPAS_FORMACION);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function listarTiposEtapasFormacion() {
        $rs = $this->ejecutarInstruccion(self::LISTAR_TIPOS_ETAPAS_FORMACION);
        return $rs ? $rs->fetch_all(MYSQLI_ASSOC) : [];
    }
}
