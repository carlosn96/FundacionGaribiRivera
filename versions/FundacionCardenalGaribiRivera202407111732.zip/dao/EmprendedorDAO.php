<?php

class EmprendedorDAO extends DAO {

    private const NOMBRE_TABLA_EMPRENDEDOR = "usuario_emprendedor";
    private const VISTA_LISTADO_EMPRENDEDORES = "lista_emprendedores";
    private const INSERTAR_NUEVO = "INSERT INTO " . self::NOMBRE_TABLA_EMPRENDEDOR . " (id_usuario) VALUES(?)";

    /*public function insertar_nuevo(Emprendedor $emprendedor) {
        $args = new PreparedStatmentArgs();
        $args->add("i", $emprendedor->get_id_usuario());
        return $this->ejecutar_instruccion_preparada(self::INSERTAR_NUEVO, $args);
    }*/
    
    

}
