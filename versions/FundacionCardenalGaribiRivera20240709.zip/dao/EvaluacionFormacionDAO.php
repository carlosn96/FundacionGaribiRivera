<?php

class EvaluacionFormacionDAO extends DAO {

    private const TABLA_LINEA_BASE = "linea_base";
    private const GUARDAR_EVALUACION = "CALL guardar_evaluacion_formacion (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private const RECUPERAR_EVALUACION = "SELECT * FROM recuperar_evaluacion_formacion WHERE id_linea_base = ?";
    private const LISTAR_OBJETIVOS_AHORRO = "SELECT * FROM listar_objetivos_ahorro WHERE id_linea_base = ?";

    public function guardar(EvaluacionFormacion $evaluacion) {
        $prep = $this->prepararInstruccion(self::GUARDAR_EVALUACION);
        $idLineaBase = $this->recuperarIDLineaBase($evaluacion->getIdUsuario());
        $prep->agregarInt($idLineaBase);
        $prep->agregarBoolean($evaluacion->getHuboBeneficioPersonal());
        $prep->agregarString($evaluacion->getBeneficiosObtenidos());
        $prep->agregarDouble($evaluacion->getVentasMensuales());
        $prep->agregarDouble($evaluacion->getGastosMensuales());
        $prep->agregarDouble($evaluacion->getSueldoMensual());
        $prep->agregarBoolean($evaluacion->getEsIngresoPrincipalPersonal());
        $prep->agregarBoolean($evaluacion->getEsIngresoPrincipalFamiliar());
        $prep->agregarBoolean($evaluacion->getTieneHabitoAhorro());
        $prep->agregarBoolean($evaluacion->getDetallesSistemaAhorro());
        $prep->agregarDouble($evaluacion->getAhorroMensual());
        $prep->agregarJSON($evaluacion->getObjetivosAhorro());
        return $prep->ejecutar();
    }

    private function recuperarIDLineaBase($idUsuario) {
        return $this->extraerIdTupla("id_linea_base", "id_usuario",
                        $idUsuario, self::TABLA_LINEA_BASE);
    }

    public function consultarEvaluacion(int $idUsuario) {
        $idLineaBase = $this->recuperarIDLineaBase($idUsuario);
        if (is_null($idLineaBase)) {
            return [];
        } else {
            $evaluacion = $this->selectPorId(self::RECUPERAR_EVALUACION, $idLineaBase);
            $evaluacion["objetivosAhorro"] = $this->selectAllPorId(self::LISTAR_OBJETIVOS_AHORRO, $idLineaBase);
            return $evaluacion;
        }
    }
}
