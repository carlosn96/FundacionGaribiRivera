<?php

class FichaInscripcionNegocio extends Objecto{

    private $domicilio_calle;
    private $domicilio_numero;
    private $domicilio_colonia;
    private $domicilio_codigo_postal;
    private $domicilio_municipio;
    private $domicilio_estado;
    private $telefono;
    private $antiguedad;
    private $num_empleados;
    private $giro;
    private $otro_giro;
    private $principal_actividad;
    private $otra_actividad;
    private $tiene_competencia;
    private $tiene_sueldo_asignado;
    private $conoce_utilidad;
    private $competencia;
    private $ingreso_personal;
    private $ingreso_familiar;
    private $estrategia_venta;
    private $otra_estrategia;
    private $producto_utilidad;
    private $utilidad;
    private $punto_equilibrio;
    private $gasto_separado;
    private $presupuesto;
    private $cliente;
    private $ventaja;

    function __construct($domicilio_calle, $domicilio_numero, $domicilio_colonia, $domicilio_codigo_postal, $domicilio_municipio, $domicilio_estado, $telefono, $antiguedad, $num_empleados, $giro, $otro_giro, $principal_actividad, $otra_actividad, $tiene_competencia, $tiene_sueldo_negocio, $conoce_utilidad_negocio, $competencia, $ingreso_personal, $ingreso_familiar, $estrategia_venta, $otra_estrategia, $producto_utilidad, $utilidad, $punto_equilibrio, $gasto_separado, $presupuesto, $cliente, $ventaja) {
        $this->domicilio_calle = $domicilio_calle;
        $this->domicilio_numero = $domicilio_numero;
        $this->domicilio_colonia = $domicilio_colonia;
        $this->domicilio_codigo_postal = $domicilio_codigo_postal;
        $this->domicilio_municipio = $domicilio_municipio;
        $this->domicilio_estado = $domicilio_estado;
        $this->telefono = $telefono;
        $this->antiguedad = $antiguedad;
        $this->num_empleados = $num_empleados;
        $this->giro = $giro;
        $this->otro_giro = $otro_giro;
        $this->principal_actividad = $principal_actividad;
        $this->otra_actividad = $otra_actividad;
        $this->tiene_competencia = $tiene_competencia;
        $this->tiene_sueldo_asignado = $tiene_sueldo_negocio;
        $this->conoce_utilidad = $conoce_utilidad_negocio;
        $this->competencia = $competencia;
        $this->ingreso_personal = $ingreso_personal;
        $this->ingreso_familiar = $ingreso_familiar;
        $this->estrategia_venta = $estrategia_venta;
        $this->otra_estrategia = $otra_estrategia;
        $this->producto_utilidad = $producto_utilidad;
        $this->utilidad = $utilidad;
        $this->punto_equilibrio = $punto_equilibrio;
        $this->gasto_separado = $gasto_separado;
        $this->presupuesto = $presupuesto;
        $this->cliente = $cliente;
        $this->ventaja = $ventaja;
    }

}
