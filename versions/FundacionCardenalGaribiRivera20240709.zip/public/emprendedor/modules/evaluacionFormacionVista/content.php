<div class="container content">
    <div class="row">
        <div class="col-12">
            <h1 class="mb-4 text-center">Evaluación de Formación</h1>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    Información General
                </div>
                <div class="card-body">
                    <dl class="row">
                        <!-- Información general se insertará aquí dinámicamente -->
                    </dl>
                </div>
            </div>
            <div class="card">
                <div class="card-header bg-success text-white">
                    Objetivos de Ahorro
                </div>
                <div class="card-body">
                    <ul class="list-group" id="objetivos-ahorro">
                        <!-- Objetivos de ahorro se insertarán aquí dinámicamente -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
