function ready() {
    var data = JSON.parse(extraerParametrosURL(window.location).rs);
    mostrarInfoGeneral(data);
    mostrarObjetivosAhorro(data.objetivosAhorro);
}

function mostrarInfoGeneral(data) {
    var $infoGeneral = $('.card-body').eq(0).find('dl');
    $infoGeneral.empty(); // Limpiar contenido anterior si lo hubiera

    // Iterar sobre las propiedades del objeto data
    $.each(data, function (key, value) {
        var dt = $('<dt>', {class: 'col-sm-6', text: formatearTexto(key)});
        var dd = $('<dd>', {class: 'col-sm-6', text: formatearValor(value)});
        $infoGeneral.append(dt).append(dd);
    });
}

// Función para mostrar los objetivos de ahorro
function mostrarObjetivosAhorro(objetivos) {
    var $objetivosAhorro = $('.card-body').eq(1).find('ul');
    $objetivosAhorro.empty(); // Limpiar contenido anterior si lo hubiera

    // Iterar sobre el array de objetivos
    $.each(objetivos, function (index, objetivo) {
        var li = $('<li>', {class: 'list-group-item', text: objetivo.descripcion});
        $objetivosAhorro.append(li);
    });
}

// Función para formatear texto (mayúscula inicial)
function formatearTexto(texto) {
    return texto.charAt(0).toUpperCase() + texto.slice(1).replace(/([A-Z])/g, ' $1').trim();
}

// Función para formatear valor (booleanos a sí/no)
function formatearValor(valor) {
    return typeof valor === 'boolean' ? (valor ? 'Sí' : 'No') : valor;
}

// Llamar a las funciones para mostrar la información

