const urlAPI = "api/EvaluacionFormacionAPI.php";
function ready() {
    crearPeticion(urlAPI, {case: "recuperarEvaluacion"}, (res) => {
        print(res);
        if (Array.isArray(res) && res.length === 0) {
            recuperarCamposFormulario();
            configurarEventos();
        } else if (typeof res === 'object' && res !== null) {
            redireccionar("../evaluacionFormacionVista?rs=" + JSON.stringify(res));
        }
    });
}

function configurarEventos() {
    $('#ventasMensuales, #gastosMensuales').on('input', () => {
        var ventas = parseFloat($('#ventasMensuales').val()) || 0;
        var gastos = parseFloat($('#gastosMensuales').val()) || 0;
        var utilidades = ventas - gastos;
        $('#utilidadesMensuales').val(utilidades);
    });

    $('input[name="huboBeneficioPersonal"]').change(function () {
        $('#beneficiosObtenidos').prop('disabled', !($(this).val() === '1'));
    });

    $('input[name="cuentaConSistemaAhorro"]').change(function () {
        var isEnabled = $(this).val() === '1';
        $('#detallesSistemaAhorro, input[name="objetivosAhorro[]"], #ahorroMensual').prop('disabled', !isEnabled);
    });
}

function enviarForm() {
    crearPeticion(urlAPI, {
        case: "guardarEvaluacion",
        data: $("#evaluacionForm").serialize()
    });
}

function recuperarCamposFormulario() {
    crearPeticion(urlAPI, {case: "recuperarCamposFormulario"}, (res) => {
        $.each(res, (group, opciones) => {
            crearGroupCheckbox($("#" + group), opciones, group);
        });
    });
}
